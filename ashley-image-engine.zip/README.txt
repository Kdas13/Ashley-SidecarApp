Ashley-Sidecar — Image Generation Engine
=========================================
Portfolio export. All code is production TypeScript from the live system.

FILE INVENTORY
--------------
API server (Express 5 / Node.js):

  api-server__routes__chat.ts          (6 326 lines)
    Primary chat route. Contains the full image-generation pipeline:
    - detectRequestedImageCount()       — parse "send 4 photos / four selfies" from user text
    - extractImageSubjects()            — pull numbered/bulleted/comma subjects for per-item generation
    - extractNoPersonText()             — extract "no people / no Ashley" constraints for Stage 3 validation
    - subjectNeedsPerson()              — route each subject to selfie vs object-only generation
    - supplementVibesForMultiImage()    — secondary LLM call to fill multi-image shortfall
    - shouldRedistributeModes()         — detect same-mode monotony and redistribute framing variety
    - POSE_VARIANCE_SLOTS               — 10 structured pose/outfit/framing/scene blocks for fan-out
    - SUPPLEMENT_MODE_CYCLE             — mode sequence for supplemented multi-image sets
    - SUPPLEMENT_FALLBACK_SCENES        — fallback scene descriptions when subject is unknown
    - sanitiseVibeForProvider()         — scrub Azure/OpenAI moderation-blocked vocabulary
    - generateAshleySelfie()            — core async function: identity pipeline, OBJECT_ONLY branch,
                                          descriptor override (redhead/blonde/brunette/blackhair),
                                          composeAppearance precedence (USER_EXPLICIT > SESSION > IDENTITY),
                                          hair colour directive, visual memory anchor injection,
                                          Stage 1 diffusion call, Stage 3 validation, cache, persist
    - POST /chat/selfie                 — accept vibe + messageId, fan-out multi-image packets,
                                          POSE_VARIANCE_SLOTS injection, per-job UUID + seed, 202 jobId response
    - GET /chat/selfie/:jobId           — poll endpoint: sibling-wait logic, ordered imageUrls[] for
                                          multi-image packets, duplicate-hash detection
    - [image:] marker parsing           — parseAllImageMarkers, multi-image / single-image routing,
                                          mode redistribution, media_attachments DB writes

  api-server__routes__image.ts
    GET /api/selfies/:filename — serve generated selfie images from object/local storage

  api-server__lib__openai.ts
    generateImageBase64()  — gpt-image-1 call via OpenAI SDK, returns raw base64 PNG
    generateImageUrl()     — convenience wrapper returning a URL string

  api-server__lib__imageIntent.ts
    encodeStoredVibe() / decodeStoredVibe()  — MODE|vibe round-trip encoding
    parseImageMarker() / parseAllImageMarkers() — [image:MODE|vibe] extraction from LLM text
    ANY_IMAGE_MARKER_STRIP_RE              — regex to clean markers from persisted text
    buildModePromptBlock()                 — assembles the structured shot-type + vibe text block
                                             per ImageMode (PORTRAIT, FULL_BODY, SCENE, SELFIE, OUTFIT,
                                             POSE_REFERENCE)
    encodeVibeWithSpec()                   — round-trips VSPEC JSON alongside the vibe

  api-server__lib__visualSpec.ts          (1 770 lines)
    VisualSpec type + full extraction pipeline:
    extractVisualSpecCompound()            — multi-signal extraction: user turn + history
    composeAppearance()                    — merge profile + spec, strip negations
    scrubVibeForOverrides()                — remove overridden colour tokens from LLM vibe text
    buildHairColourDirective()             — emit positive + forbidden colour anchor paragraph
    extractIdentityCore()                  — split profile.appearance into stable (face/eyes/skin)
                                             vs mutable (hair) layers
    assertIdentityCoreIsClean()            — verify no hair colour leaked into stable layer
    renderIdentityCore()                   — stable-identity string for STABLE ASHLEY IDENTITY block
    encodeVibeWithSpec()                   — VSPEC base64 marker encoding
    extractVisualSpecFromVibe()            — recover spec from marker for prompt assembly
    makeEmptySpec()                        — zero-fields VisualSpec for descriptor mode

  api-server__lib__visualMemory.ts
    VisualMemory store (in-memory + JSON persistence):
    getVisualMemory() / setVisualMemory()  — CRUD for named anchors
    formatVisualMemoryDirective()          — build Scene Anchor block injected into diffusion prompt
    extractMemoryIdFromVibe()              — parse {{VMEM}} marker from LLM-written vibe

  api-server__lib__imageFollowUp.ts       (1 537 lines)
    Post-generation follow-up pipeline:
    detectPhantomImageDelivery()           — detect roleplay-prose false delivery without [image:] marker
    validateNoPersonInB64()                — Stage 3 Claude vision call: confirm no human in OBJECT_ONLY
    selfieCache / pruneSelfieCache()       — LRU prompt→selfieId cache (prevents identical regeneration)
    selfieInFlight                         — dedup map: one in-flight Promise per cache key
    selfieJobs / setSelfieJob()            — job registry (pending → ready / failed)
    startSelfieGeneration()                — background async wrapper; writes job, patches messages row,
                                             patches media_attachments row on completion
    pruneSelfieJobs()                      — evict stale jobs from registry
    persistSelfieCache() / loadSelfieCache() — warm cache across restarts

  api-server__lib__contentPolicy.ts
    buildSelfiePromptSafetyPrefix()        — generates the safety preamble injected at the top of
                                             every diffusion prompt

  api-server__lib__textLLM.ts
    generateChatText() / streamChatText()  — unified LLM adapter; routes by ASHLEY_TEXT_PROVIDER
                                             (gemini = Gemini 2.5 Flash, anthropic = Claude Sonnet 4.6)
                                             Used by supplementVibesForMultiImage() (always anthropic)
                                             and Stage 3 validateNoPersonInB64()

  api-server__lib__storage.ts
    saveSelfie()     — persist base64 PNG to Replit Object Storage (fallback: local /selfies/)
    loadSelfie()     — read back by selfieId
    publicBaseUrl()  — resolve absolute URL prefix for image links

  api-server__lib__selfieCap.ts
    tryClaimSelfieSlot()  — per-device daily selfie cap (currently a pass-through stub;
                            ASHLEY_SELFIE_DAILY_CAP default is enforced in the route handler)

Mobile client (Expo / React Native):

  mobile__lib__imageGate.ts
    shouldEnableImageGeneration()  — device-side gate: checks profile flag + session toggle
    ImageGateResult type

  mobile__lib__aiClient.ts
    postSelfieRequest()            — POST /api/chat/selfie with jobId + optional sortOrder[]
    pollSelfieJob()                — GET /api/chat/selfie/:jobId, handles imageUrls[] for multi-image
    sendImageRequest()             — multi-image upload path (up to 10 images)

  mobile__app__chat.tsx           (3 000+ lines)
    Image rendering layer:
    - hasGallery detection          — imageUrls.length > 1 triggers gallery layout
    - Full-screen viewer modal      — shared single/multi-image; page-dot indicator for galleries
    - Swipeable multi-image strip   — horizontal scroll, page dots, tap-to-fullscreen
    - selfiePending state           — "taking a selfie..." spinner + retry button
    - Save-to-library integration   — expo-media-library save with permission prompt

ARCHITECTURE SUMMARY
--------------------
Two-call selfie design (prevents connection timeout on slow image gen):
  1. POST /api/chat/reply  — LLM writes text + [image:MODE|vibe] markers; server encodes vibes,
                             writes media_attachments rows, responds immediately with messageId
  2. POST /api/chat/selfie — client fires one call per vibe (or one call + fan-out for old APK);
                             server starts background generation, responds 202 { jobId, jobIds[] }
  3. GET  /api/chat/selfie/:jobId — client polls; server holds "ready" until all siblings done,
                             then returns { imageUrl, imageUrls[] }

Multi-image (up to 10):
  - LLM emits N [image:] markers → server caps at 10, redistributes modes if all identical
  - Deficit correction: if LLM emitted fewer markers than the user requested, supplementVibesForMultiImage()
    fills the gap (subject-isolation path for explicit lists; fallback-scene path for count-only requests)
  - Fan-out: one media_attachments row per vibe; POSE_VARIANCE_SLOTS injects unique
    pose/outfit/expression/framing/scene block per job so images are visually distinct
  - Sibling-wait: poll endpoint returns "pending" until every sibling job resolves,
    then returns ordered imageUrls[] (null for failed slots)

Appearance precedence (USER_EXPLICIT > SESSION_MEMORY > DEFAULT_IDENTITY):
  - VisualSpec extracted from current turn + recent history
  - composeAppearance() merges profile.appearance with spec, stripping negated tokens
  - buildHairColourDirective() emits a colour-anchor block that defeats model cool-tone gravity
  - Descriptor override (redhead / blonde / brunette / blackhair): complete identity isolation —
    only face/eyes/skin carry through; hair replaced entirely; lavender forbidden list appended
  - OBJECT_ONLY path: no Ashley, no person; Stage 3 Claude vision validates compliance

Stage 3 validation:
  - validateNoPersonInB64(): sends generated image to Claude vision; returns true = no person
  - RETRY_STRENGTHENERS: up to 3 escalating no-person directives on consecutive attempts
  - On exhaustion: returns null → mobile shows error, no contaminated image delivered

