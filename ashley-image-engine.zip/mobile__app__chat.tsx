import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Animated,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Icon as Feather } from "@/components/Icon";
import { router } from "expo-router";
import * as Clipboard from "expo-clipboard";
import * as FileSystem from "expo-file-system/legacy";
import * as MediaLibrary from "expo-media-library";
import * as ImagePicker from "expo-image-picker";
import * as DocumentPicker from "expo-document-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  useDocumentIngest,
  useMessages,
  useStreamMessage,
  useContinueMessage,
  useStopStream,
  useActiveStream,
  useSendImage,
  useMarkImageRemembered,
  useClearMessages,
  useRetrySelfie,
  useRetryUnansweredReply,
  useSelfieInFlight,
} from "@/lib/useMessages";
import { usePresenceLoop, type PresenceSignal } from "@/lib/usePresenceLoop";
import { useProfile, useUpdateProfile } from "@/lib/useProfile";
import { useVoiceRecorder, VOICE_MAX_DURATION_MS } from "@/lib/voiceInput";
import { useTranscribeAudioStream } from "@/lib/useVoice";
import { useTtsPlayback } from "@/lib/voiceOutput";
import { useSpeakMessage, type SpeakStatus } from "@/lib/useSpeakMessage";
import type {
  ImageAnalysisMode,
  ImageCategory,
  Message,
  ReplyToRef,
} from "@/lib/storage";
import colors from "@/constants/colors";
import { SwipeToReply } from "@/components/SwipeToReply";
import { useImageGate } from "@/lib/imageGate";

const RELATIONSHIP_MODE_PRESETS = [
  "Friend",
  "Best friend",
  "Companion",
  "Romantic partner",
  "Mentor/coach",
  "Creative partner",
];

// Maximum length of the quote preview we capture from a swiped message.
// Keeps storage and the on-screen quote header from getting unwieldy.
const REPLY_PREVIEW_MAX = 140;

// True when the bundle has both the API key and a reachable base URL baked in.
// Both are EXPO_PUBLIC_* variables inlined at build time. False only in dev
// builds where the env vars were not set; in production both are always present.
// Used to gate Continue/Retry so a misconfigured build fails visibly rather
// than silently. Does not gate the main send button — getApiBase() throws there,
// surfacing the error banner, which is sufficient for dev-time discovery.
const isApiConfigured =
  !!process.env.EXPO_PUBLIC_API_KEY &&
  !!(process.env.EXPO_PUBLIC_API_BASE ?? process.env.EXPO_PUBLIC_DOMAIN);

/**
 * Map a raw error message to a short category code shown in the error banner.
 * Keeps the banner informative without exposing raw server text to the user.
 */
function classifyError(msg: string | null): string {
  if (!msg) return "UNKNOWN";
  if (!isApiConfigured) return "CONFIG_MISSING";
  const m = msg.toLowerCase();
  if (
    m.includes("rate") ||
    m.includes("429") ||
    m.includes("ratelimit") ||
    m.includes("too many")
  )
    return "RATE_LIMIT";
  if (m.includes("timeout") || m.includes("timed out")) return "TIMEOUT";
  if (
    m.includes("network") ||
    m.includes("failed to fetch") ||
    m.includes("network request failed")
  )
    return "NETWORK";
  if (m.includes("abort")) return "ABORTED";
  return "PROVIDER_ERROR";
}

/**
 * Generate a compact unique id for a single send attempt.
 * Not cryptographically random — just needs to be unique within a session
 * so the server can detect in-flight duplicates.
 */
function generateRequestId(): string {
  return `req-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

// Image picker — visible labels for category + analysis-mode chips.
const IMAGE_CATEGORIES: { value: ImageCategory; label: string }[] = [
  { value: "art_progress", label: "Art progress" },
  { value: "clothing_design", label: "Clothing design" },
  { value: "ashley_identity", label: "Ashley identity" },
  { value: "app_screenshot", label: "App screenshot" },
  { value: "medical", label: "Medical" },
  { value: "other", label: "Other" },
];

const IMAGE_MODES: { value: ImageAnalysisMode; label: string; hint: string }[] =
  [
    { value: "quick", label: "Quick reaction", hint: "short, warm, what jumps out" },
    { value: "critique", label: "Critique", hint: "honest feedback, what could shift" },
    { value: "stepbystep", label: "Step by step", hint: "walk through it methodically" },
    { value: "debug", label: "Debug", hint: "what's wrong + how to fix" },
    { value: "extract", label: "Extract", hint: "pull out text / numbers / structure" },
    { value: "compare", label: "Compare", hint: "compare with what came before" },
  ];

type PickedImage = {
  uri: string;
  base64: string;
  mimeType: string;
  width?: number;
  height?: number;
};

function mimeFromUri(uri: string, fallback: string | undefined): string {
  if (fallback) return fallback;
  const lower = uri.toLowerCase();
  if (lower.endsWith(".png")) return "image/png";
  if (lower.endsWith(".webp")) return "image/webp";
  if (lower.endsWith(".gif")) return "image/gif";
  if (lower.endsWith(".heic")) return "image/heic";
  return "image/jpeg";
}

function buildReplyPreview(message: Message): ReplyToRef {
  const raw = (message.content ?? "").trim();
  // If the swiped message is a photo with no caption, surface a friendly
  // placeholder so the quote bar isn't blank.
  const text = raw.length > 0 ? raw : message.imageUrl ? "Photo" : "Message";
  const collapsed = text.replace(/\s+/g, " ");
  const preview =
    collapsed.length > REPLY_PREVIEW_MAX
      ? `${collapsed.slice(0, REPLY_PREVIEW_MAX - 1).trimEnd()}…`
      : collapsed;
  return { id: message.id, role: message.role, preview };
}

export default function ChatScreen(): React.JSX.Element {
  const insets = useSafeAreaInsets();
  const [draft, setDraft] = useState("");
  // When the user swipes a bubble, we stash a quote reference here. The
  // input bar grows to show the preview + an X to dismiss; sending the
  // next message attaches the quote and clears this state.
  const [replyingTo, setReplyingTo] = useState<ReplyToRef | null>(null);
  const inputRef = useRef<TextInput>(null);
  const listRef = useRef<FlatList<Message>>(null);

  // Messages typed while a stream is in-flight are pushed here rather than
  // dropped. The drain effect below processes them in FIFO order as each
  // stream settles (done / error / interrupted).
  const messageQueue = useRef<Array<{ content: string; replyTo: ReplyToRef | null; requestId: string }>>([]);
  const [queueSize, setQueueSize] = useState(0);

  const messagesQuery = useMessages();
  const streamMutation = useStreamMessage();
  const continueMutation = useContinueMessage();
  const stopStreamMutation = useStopStream();
  const activeStream = useActiveStream();
  const presence = usePresenceLoop();
  const sendImageMutation = useSendImage();
  const docIngestMutation = useDocumentIngest();
  const markImageRemembered = useMarkImageRemembered();
  const clearMutation = useClearMessages();
  const retryUnanswered = useRetryUnansweredReply();

  // Paperclip / image-upload modal state. Held open from "picked an
  // image" until either Send or Cancel.
  const [pickedImage, setPickedImage] = useState<PickedImage | null>(null);
  // Extra images beyond the first when the user picks a set (max 3 extras = 4 total).
  // Stored as base64 + mimeType only — no URI needed for send.
  const [pickedExtraImages, setPickedExtraImages] = useState<
    { base64: string; mimeType: string; uri: string }[]
  >([]);
  const [imageCategory, setImageCategory] = useState<ImageCategory>("other");
  const [imageMode, setImageMode] = useState<ImageAnalysisMode>("quick");
  const [imageCaption, setImageCaption] = useState("");
  const [imagePickerError, setImagePickerError] = useState<string | null>(null);

  const imageGenEnabled = useImageGate();
  const profileQuery = useProfile();
  const updateProfile = useUpdateProfile();
  const relationshipMode = (profileQuery.data?.relationshipMode ?? "").trim();
  const ashleyName = (profileQuery.data?.name ?? "Ashley").trim() || "Ashley";
  const [relPickerOpen, setRelPickerOpen] = useState(false);
  const [customMode, setCustomMode] = useState("");
  const [showCustomInput, setShowCustomInput] = useState(false);
  const isPresetMode = RELATIONSHIP_MODE_PRESETS.includes(relationshipMode);
  // BUILD MARKER — visible canary so Kane can confirm at a glance
  // whether his Expo Go has actually loaded the latest bundle. If
  // the subtitle on his phone says "Best friend mode" with no "B3"
  // suffix, the bundle is still stale (Expo Go hasn't fetched the
  // current Metro bundle no matter what reload/clear-cache he tries).
  // Increment the suffix on each diagnostic push (B3 → B4 → …).
  const BUILD_MARKER = "B7";
  const subtitleLabel = relationshipMode
    ? `${relationshipMode} mode • ${BUILD_MARKER}`
    : `tap to set relationship mode • ${BUILD_MARKER}`;

  const applyMode = useCallback(
    async (value: string) => {
      const next = value.trim().slice(0, 80);
      try {
        await updateProfile.mutateAsync({ relationshipMode: next });
        setRelPickerOpen(false);
        setShowCustomInput(false);
        setCustomMode("");
      } catch (e) {
        Alert.alert("Couldn't save", e instanceof Error ? e.message : "Try again.");
      }
    },
    [updateProfile],
  );

  const messages = useMemo<Message[]>(
    () => messagesQuery.data ?? [],
    [messagesQuery.data],
  );

  // Inverted FlatList renders data[0] at the visually-bottom and stays
  // anchored to scroll offset 0 (the newest message) by default — no
  // manual scrollToEnd machinery needed. The underlying `messages`
  // array stays in its natural [oldest, ..., newest] order so the
  // unanswered-tail / lastMessage / hasUnansweredTail logic below
  // continues to work; we only reverse a memoized view for rendering.
  const reversedMessages = useMemo(() => {
    const copy = messages.slice();
    copy.reverse();
    return copy;
  }, [messages]);

  const sendError =
    streamMutation.error instanceof Error ? streamMutation.error.message : null;

  // Auto-retry: if the latest message is from the user (Ashley never
  // replied — common when the api-server gets recycled mid-request) keep
  // poking the server every ~12s until her reply lands. The retry
  // mutation handles the no-op case internally, and `appendIfStillCurrent`
  // makes sure we don't double-up if the user types something new while a
  // retry is in flight. We also dismiss the stale send-error banner once a
  // retry succeeds so the green path looks clean.
  const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
  // Image messages have their own dedicated /chat/image flow — text-only
  // /chat doesn't know what to do with them. So an unanswered image
  // message at the tail is NOT a candidate for the auto-retry; the user
  // can re-tap the paperclip if it really stalled. (See architect note
  // about /chat being unable to retry image-message ids.)
  const hasUnansweredTail = lastMessage?.role === "user" && !lastMessage?.imageUrl;
  const retryMutateRef = useRef(retryUnanswered.mutateAsync);
  retryMutateRef.current = retryUnanswered.mutateAsync;
  const sendResetRef = useRef(streamMutation.reset);
  sendResetRef.current = streamMutation.reset;
  const inFlightRetryRef = useRef(false);
  // Ref-wrapped so the drain effect captures a fresh closure on every render
  // without needing the function itself in deps (same pattern as retryMutateRef).
  const drainQueueRef = useRef<() => void>(() => {});
  // Synchronous lock — set to true BEFORE calling mutateAsync so that a
  // second send() fired in the same render cycle (before isPending re-renders)
  // still sees the lock and goes to the queue instead of firing concurrently.
  const isSendingRef = useRef(false);
  useEffect(() => {
    if (!hasUnansweredTail) return;
    if (streamMutation.isPending) return;
    let cancelled = false;
    const tryOnce = () => {
      if (cancelled || inFlightRetryRef.current) return;
      inFlightRetryRef.current = true;
      retryMutateRef
        .current()
        .then((result) => {
          if (result) {
            // The retry landed Ashley's reply — clear any stale error
            // banner from the original failed send.
            sendResetRef.current();
          }
        })
        .catch(() => {
          // Silent — the next tick will try again.
        })
        .finally(() => {
          inFlightRetryRef.current = false;
        });
    };
    const initial = setTimeout(tryOnce, 600);
    const interval = setInterval(tryOnce, 4000);
    return () => {
      cancelled = true;
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, [hasUnansweredTail, streamMutation.isPending]);

  // Triggered when SwipeToReply commits inside a bubble. Captures a quote
  // preview, focuses the input so the keyboard stays up, and replaces any
  // previous in-progress quote.
  const handleStartReply = useCallback((message: Message) => {
    setReplyingTo(buildReplyPreview(message));
    // Slight delay so the keyboard doesn't fight the gesture's spring.
    requestAnimationFrame(() => inputRef.current?.focus());
  }, []);

  const cancelReply = useCallback(() => {
    setReplyingTo(null);
  }, []);

  // ----- Voice push-to-talk (Stages 1 + 2) -------------------------------
  // Hold the mic to record, release to transcribe + insert into the draft.
  // Stage 2 streams partial transcripts back over SSE so words appear in
  // the recording banner while the model is still producing text instead
  // of the user sitting in silence for 2-3s after release. The hook
  // silently falls back to the Stage 1 endpoint if streaming fails, so
  // the user always gets a transcript. Text remains the canonical
  // fallback at all times.
  const voice = useVoiceRecorder();
  const transcribeMutation = useTranscribeAudioStream();
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [voicePartial, setVoicePartial] = useState("");

  const tts = useTtsPlayback();
  const { speakMessage, getSpeakStatus } = useSpeakMessage(tts);
  // Buffer the partial text in a ref too so the onDelta callback (created
  // once per call below) can accumulate without going stale between
  // renders. The setVoicePartial call is just for UI redraw.
  const voicePartialRef = useRef("");

  const handleMicPressIn = useCallback(async () => {
    setVoiceError(null);
    setVoicePartial("");
    voicePartialRef.current = "";
    // Barge-in: re-opening the mic silences any in-flight spoken reply.
    // MUST await stopAsync so TTS teardown and its setAudioModeAsync reset
    // complete before voice.start() requests recording audio focus — the
    // original race between these two setAudioModeAsync calls is what was
    // killing both TTS and STT after the first message.
    await tts.stopAsync();
    try {
      const granted = await voice.ensurePermission();
      if (!granted) {
        setVoiceError("Microphone permission denied");
        return;
      }
      await voice.start();
    } catch (e) {
      setVoiceError(e instanceof Error ? e.message : "Couldn't start recording");
    }
  }, [voice, tts]);

  const handleMicPressOut = useCallback(async () => {
    let audio;
    try {
      audio = await voice.stop();
    } catch (e) {
      setVoiceError(e instanceof Error ? e.message : "Couldn't stop recording");
      return;
    }
    if (!audio) {
      // Tap (not hold) or empty clip — nothing to do.
      return;
    }
    try {
      const { transcript } = await transcribeMutation.mutateAsync({
        audio,
        onDelta: (chunk) => {
          voicePartialRef.current += chunk;
          setVoicePartial(voicePartialRef.current);
        },
      });
      // Clear the partial preview now that we have the authoritative
      // final transcript — the banner disappears and the text lands in
      // the draft below.
      voicePartialRef.current = "";
      setVoicePartial("");
      if (transcript.length === 0) {
        setVoiceError("Didn't catch that — try again");
        return;
      }
      // Append to existing draft so dictation can stack with typed text.
      setDraft((prev) => {
        const trimmed = prev.trim();
        if (trimmed.length === 0) return transcript;
        return `${trimmed} ${transcript}`;
      });
      requestAnimationFrame(() => inputRef.current?.focus());
    } catch (e) {
      voicePartialRef.current = "";
      setVoicePartial("");
      setVoiceError(e instanceof Error ? e.message : "Couldn't transcribe");
    }
  }, [voice, transcribeMutation]);

  // Auto-stop recording at the hard ceiling so the user can't accidentally
  // leave the mic open. We just call the same handler the press-out path uses.
  useEffect(() => {
    if (voice.state !== "recording") return;
    if (voice.elapsedMs < VOICE_MAX_DURATION_MS) return;
    void handleMicPressOut();
  }, [voice.state, voice.elapsedMs, handleMicPressOut]);

  // Stable references for the presence-loop dispatch + watchdog hooks
  // so we don't churn the streamHooks memo every keystroke.
  const presenceDispatch = presence.dispatch;
  const presenceNoteDelta = presence.noteDelta;
  const streamHooks = useMemo(
    () => ({
      onFirstDelta: () => presenceDispatch({ type: "STREAM_FIRST_TOKEN" }),
      onDeltaArrived: () => presenceNoteDelta(),
    }),
    [presenceDispatch, presenceNoteDelta],
  );

  // Outcome handler shared by send/continue/retry paths — translates
  // the mutation result into the right presence-loop event and kicks
  // off TTS on a clean done.
  const handleStreamOutcome = useCallback(
    (result: {
      ashley: Message | null;
      outcome: { kind: "done" | "interrupted" | "error" };
    }) => {
      if (result.outcome.kind === "interrupted") {
        presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
        return;
      }
      if (result.outcome.kind === "error") {
        presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
        return;
      }
      presenceDispatch({
        type: "STREAM_END",
        replyLength: result.ashley?.content?.length ?? 0,
      });
    },
    [presenceDispatch],
  );

  // Always up-to-date — captures the latest streamHooks / handleStreamOutcome
  // without adding them to the useEffect dep array.
  drainQueueRef.current = () => {
    if (isSendingRef.current || streamMutation.isPending) return;
    const next = messageQueue.current.shift();
    if (!next) return;
    setQueueSize(messageQueue.current.length);
    isSendingRef.current = true;
    streamMutation.reset();
    tts.stop();
    presenceDispatch({ type: "USER_SEND" });
    streamMutation
      .mutateAsync({
        content: next.content,
        replyTo: next.replyTo,
        requestId: next.requestId,
        hooks: streamHooks,
      })
      .then(handleStreamOutcome)
      .catch(() => presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" }))
      .finally(() => {
        isSendingRef.current = false;
      });
  };

  // Fire once each time the stream settles (isPending flips to false).
  // Guard on hasUnansweredTail: if the previous stream errored before producing
  // any Ashley row, let the auto-retry mechanism recover that turn first so we
  // don't collide with it by sending the next queued message simultaneously.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (streamMutation.isPending || hasUnansweredTail) return;
    if (messageQueue.current.length > 0) {
      drainQueueRef.current();
    }
  }, [streamMutation.isPending, hasUnansweredTail]);

  const send = useCallback(() => {
    const content = draft.trim();
    if (!content) return;
    const replyToSnapshot = replyingTo;
    setDraft("");
    setReplyingTo(null);
    const requestId = generateRequestId();
    // isSendingRef is a synchronous lock that catches two taps in the same
    // render cycle before React re-renders with isPending=true. Combined with
    // the isPending check it prevents concurrent mutateAsync calls entirely.
    if (isSendingRef.current || streamMutation.isPending) {
      // A stream is already in flight (or starting) — queue rather than drop.
      // The drain effect fires as soon as isPending flips to false.
      messageQueue.current.push({ content, replyTo: replyToSnapshot, requestId });
      setQueueSize(messageQueue.current.length);
      return;
    }
    isSendingRef.current = true;
    streamMutation.reset();
    // Sending a fresh message supersedes any reply Ashley is currently
    // speaking — silence her so the new turn isn't talked over.
    tts.stop();
    presenceDispatch({ type: "USER_SEND" });
    streamMutation
      .mutateAsync({ content, replyTo: replyToSnapshot, requestId, hooks: streamHooks })
      .then(handleStreamOutcome)
      .catch(() => {
        // Stream errors surface via streamMutation.error and the
        // presence loop pivots to interrupted so the recovery actions
        // (Continue / Retry) can be offered on whatever partial we
        // captured.
        presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
      })
      .finally(() => {
        isSendingRef.current = false;
      });
  }, [
    draft,
    streamMutation,
    replyingTo,
    tts,
    presenceDispatch,
    streamHooks,
    handleStreamOutcome,
  ]);

  // Stop the in-flight stream. The server-side abort is fire-and-forget
  // (idempotent on the server), and the local AbortController on the
  // SSE fetch is what actually flips us into the `interrupted` event
  // path on the client. We dispatch USER_INTERRUPT immediately so the
  // send/stop button swaps back the moment the user taps it, even
  // before the SSE close round-trips.
  const handleStop = useCallback(() => {
    if (!activeStream) return;
    presenceDispatch({ type: "USER_INTERRUPT" });
    void stopStreamMutation
      .mutateAsync(activeStream.streamId)
      .catch(() => {
        /* idempotent — fine if it 404s */
      });
  }, [activeStream, presenceDispatch, stopStreamMutation]);

  // Continue from an interrupted reply — the server prepends the
  // partial as an assistant turn and nudges Claude to pick up where
  // she left off without restarting the sentence.
  const handleContinue = useCallback(
    (interruptedMessageId: string) => {
      if (continueMutation.isPending || streamMutation.isPending) return;
      presenceDispatch({ type: "USER_SEND" });
      continueMutation
        .mutateAsync({
          continueFromMessageId: interruptedMessageId,
          hooks: streamHooks,
        })
        .then(handleStreamOutcome)
        .catch(() => {
          presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
        });
    },
    [
      continueMutation,
      streamMutation.isPending,
      presenceDispatch,
      streamHooks,
      handleStreamOutcome,
    ],
  );

  // Retry — the user wants Ashley to start the reply over from
  // scratch. Look up the original user prompt that produced the
  // interrupted bubble and re-fire it. The interrupted bubble stays
  // visible as the "before" half; this is intentional so the user can
  // still tap Continue if they preferred that branch.
  const handleRetryFromInterrupted = useCallback(
    (interruptedMessageId: string) => {
      if (continueMutation.isPending || streamMutation.isPending) return;
      const idx = messages.findIndex((m) => m.id === interruptedMessageId);
      if (idx < 1) return;
      // Walk back to the most recent user message (skipping any prior
      // ashley bubbles, e.g. a chain of interrupted attempts).
      let candidate: Message | null = null;
      for (let i = idx - 1; i >= 0; i -= 1) {
        const m = messages[i];
        if (m && m.role === "user") {
          candidate = m;
          break;
        }
      }
      if (!candidate) return;
      presenceDispatch({ type: "USER_SEND" });
      streamMutation.reset();
      streamMutation
        .mutateAsync({
          content: candidate.content,
          replyTo: candidate.replyTo ?? null,
          hooks: streamHooks,
        })
        .then(handleStreamOutcome)
        .catch(() => {
          presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
        });
    },
    [
      messages,
      streamMutation,
      continueMutation.isPending,
      presenceDispatch,
      streamHooks,
      handleStreamOutcome,
    ],
  );

  // Auto-retry once on connection-dip. The watchdog fires CONNECTION_DIP
  // when the SSE goes silent for ~7s while we're still in `speaking`.
  // We try the stop+continue dance exactly one time per stream — if the
  // network is genuinely down the user will see the "connection dipped…"
  // signal stick around and can choose to manually Continue / Retry.
  const autoRetriedStreamRef = useRef<string | null>(null);
  useEffect(() => {
    if (!activeStream) {
      autoRetriedStreamRef.current = null;
      return;
    }
    const dipped = presence.signals.some((s) => s.type === "connection_dip");
    if (!dipped) return;
    if (autoRetriedStreamRef.current === activeStream.streamId) return;
    autoRetriedStreamRef.current = activeStream.streamId;
    const interruptedId = activeStream.streamId;
    void (async () => {
      try {
        await stopStreamMutation.mutateAsync(interruptedId);
      } catch {
        /* idempotent */
      }
      // Small breath so the server can flip the row to interrupted
      // before we ask it to look the row up for the continuation.
      await new Promise<void>((r) => setTimeout(r, 250));
      try {
        const result = await continueMutation.mutateAsync({
          continueFromMessageId: interruptedId,
          hooks: streamHooks,
        });
        handleStreamOutcome(result);
      } catch {
        presenceDispatch({ type: "STREAM_INTERRUPTED_RECEIVED" });
      }
    })();
  }, [
    presence.signals,
    activeStream,
    stopStreamMutation,
    continueMutation,
    streamHooks,
    handleStreamOutcome,
    presenceDispatch,
  ]);

  // Presence signals are ephemeral — they fade out after ~4s. We keep
  // the reducer pure by handling the dismiss timer here rather than
  // baking it into `presenceReducer`.
  useEffect(() => {
    if (presence.signals.length === 0) return;
    const timers = presence.signals.map((sig) =>
      setTimeout(() => {
        presenceDispatch({ type: "DISMISS_SIGNAL", key: sig.key });
      }, 4000),
    );
    return () => {
      for (const t of timers) clearTimeout(t);
    };
  }, [presence.signals, presenceDispatch]);

  // Wrap setDraft so the input change drives the listening/idle
  // transitions in the presence loop. We do *not* mutate state when
  // we're already mid-stream — typing the next message while she
  // replies should not yank her out of speaking.
  const handleDraftChange = useCallback(
    (next: string) => {
      setDraft(next);
      if (next.trim().length === 0) {
        presenceDispatch({ type: "USER_CLEAR_DRAFT" });
      } else {
        presenceDispatch({ type: "USER_TYPING" });
      }
    },
    [presenceDispatch],
  );

  const confirmClear = useCallback(() => {
    if (clearMutation.isPending) return;
    Alert.alert(
      "Clear conversation?",
      "This will delete the conversation from both this device and our server. Older messages may have already been processed by the AI provider to generate replies and cannot be recalled from there.",
      [
        { text: "Keep", style: "cancel" },
        {
          text: "Clear",
          style: "destructive",
          onPress: () => clearMutation.mutate(),
        },
      ],
    );
  }, [clearMutation]);

  // ---------------------------------------------------------------------
  // Paperclip / image-upload flow
  // ---------------------------------------------------------------------

  const openImagePicker = useCallback(async () => {
    setImagePickerError(null);
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert(
          "Permission needed",
          "Allow photo library access so you can send Ashley pictures.",
        );
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsMultipleSelection: true,
        selectionLimit: 10,
        base64: true,
        // Each photo compresses to ~9 MB base64 at q=0.85.
        // Server body parser cap is 100 MB, well above 10 × 9 MB.
        quality: 0.85,
        exif: false,
      });
      if (result.canceled) return;
      const [primaryAsset, ...extraAssets] = result.assets;
      if (!primaryAsset || !primaryAsset.base64) {
        Alert.alert("Couldn't read image", "Try again with a different photo.");
        return;
      }
      // Base64 size cap — at q=0.85 a photo runs ~9 MB. Cap at 15 MB to
      // give headroom without risking a 413 on a single large-sensor image.
      if (primaryAsset.base64.length > 15 * 1024 * 1024) {
        Alert.alert(
          "Photo too large",
          "That image exceeds the size limit. Try a smaller one or take a new photo.",
        );
        return;
      }
      const mimeType = mimeFromUri(primaryAsset.uri, primaryAsset.mimeType ?? undefined);
      // Block HEIC at the picker — Claude vision can't read it. iOS users
      // can usually pick a JPEG version of the same photo.
      if (mimeType === "image/heic") {
        Alert.alert(
          "HEIC not supported",
          "iPhone HEIC photos can't be analysed yet. Try sharing the photo as JPEG.",
        );
        return;
      }
      setPickedImage({
        uri: primaryAsset.uri,
        base64: primaryAsset.base64,
        mimeType,
        width: primaryAsset.width,
        height: primaryAsset.height,
      });
      // Collect any additional images the user selected (beyond the first).
      // Filter out HEIC and assets without base64 silently.
      const extras = extraAssets
        .filter(
          (a) =>
            a.base64 &&
            mimeFromUri(a.uri, a.mimeType ?? undefined) !== "image/heic",
        )
        .map((a) => ({
          base64: a.base64!,
          mimeType: mimeFromUri(a.uri, a.mimeType ?? undefined),
          uri: a.uri,
        }));
      setPickedExtraImages(extras);
      setImageCategory("other");
      setImageMode("quick");
      setImageCaption("");
    } catch (e) {
      Alert.alert(
        "Couldn't open photos",
        e instanceof Error ? e.message : "Try again.",
      );
    }
  }, []);

  const cancelImagePicker = useCallback(() => {
    setPickedImage(null);
    setPickedExtraImages([]);
    setImagePickerError(null);
  }, []);

  // Document picker — reads up to 10 .txt files (combined cap ~40,000 words /
  // 280,000 chars), POSTs to /api/documents/ingest, and inserts Ashley's reply
  // directly into the chat.
  const openDocumentPicker = useCallback(async () => {
    if (docIngestMutation.isPending) return;
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "text/plain",
        copyToCacheDirectory: true,
        multiple: true,
      });
      if (result.canceled) return;
      const assets = result.assets ?? [];
      if (assets.length === 0) return;

      const parts: string[] = [];
      let totalLength = 0;
      for (const asset of assets.slice(0, 10)) {
        const raw = await FileSystem.readAsStringAsync(asset.uri);
        totalLength += raw.length;
        if (totalLength > 280_000) {
          Alert.alert(
            "Documents too large",
            "The combined total is over the ~40,000-word limit. Try fewer or shorter files.",
          );
          return;
        }
        const name = asset.name ?? "document.txt";
        parts.push(
          assets.length > 1 ? `--- ${name} ---\n\n${raw.trim()}` : raw.trim(),
        );
      }

      const combined = parts.join("\n\n");
      const filename =
        assets.length === 1
          ? (assets[0]?.name ?? "document.txt")
          : `${assets.length} documents`;
      await docIngestMutation.mutateAsync({ content: combined, filename });
    } catch (e) {
      Alert.alert(
        "Couldn't read file",
        e instanceof Error ? e.message : "Try again.",
      );
    }
  }, [docIngestMutation]);

  // Section 6 (master spec): remove a single image from the selection by index
  // (0 = primary, 1..N = extras). Promotes the next extra to primary when idx=0.
  const removePicked = useCallback(
    (idx: number) => {
      if (idx === 0) {
        if (pickedExtraImages.length > 0) {
          const [promoted, ...rest] = pickedExtraImages;
          setPickedImage({ uri: promoted!.uri, base64: promoted!.base64, mimeType: promoted!.mimeType });
          setPickedExtraImages(rest);
        } else {
          setPickedImage(null);
        }
      } else {
        setPickedExtraImages((prev) => prev.filter((_, i) => i !== idx - 1));
      }
    },
    [pickedExtraImages],
  );

  const sendPickedImage = useCallback(async () => {
    if (!pickedImage || sendImageMutation.isPending) return;
    const replyToSnapshot = replyingTo;
    const captionSnapshot = imageCaption.trim();
    const picked = pickedImage;
    const extras = pickedExtraImages;
    const cat = imageCategory;
    const mode = imageMode;
    setImagePickerError(null);
    try {
      await sendImageMutation.mutateAsync({
        uri: picked.uri,
        base64: picked.base64,
        mimeType: picked.mimeType,
        ...(extras.length > 0 ? { extraImages: extras } : {}),
        selectedCount: 1 + extras.length,
        category: cat,
        mode,
        caption: captionSnapshot,
        ...(replyToSnapshot ? { replyTo: replyToSnapshot } : {}),
      });
      setPickedImage(null);
      setPickedExtraImages([]);
      setImageCaption("");
      setReplyingTo(null);
    } catch (err) {
      setImagePickerError(
        err instanceof Error
          ? err.message
          : "Couldn't send the image — try again.",
      );
    }
  }, [
    pickedImage,
    pickedExtraImages,
    sendImageMutation,
    imageCaption,
    imageCategory,
    imageMode,
    replyingTo,
  ]);

  // ---------------------------------------------------------------------
  // Remember card — shown under Ashley's reply when the previous message
  // is a user-uploaded image with an undecided imageRemembered flag.
  // ---------------------------------------------------------------------

  const onRemember = useCallback(
    (userMessageId: string, decision: "remember" | "visual" | "dismiss") => {
      markImageRemembered.mutate({ messageId: userMessageId, decision });
    },
    [markImageRemembered],
  );

  const renderItem = useCallback(
    ({ item, index }: { item: Message; index: number }) => {
      const prev = index > 0 ? messages[index - 1] : null;
      const showRememberCard =
        item.role === "ashley" &&
        prev &&
        prev.role === "user" &&
        !!prev.imageUrl &&
        prev.imageRemembered === null &&
        prev.imageCategory != null;
      return (
        <>
          <MessageBubble
            message={item}
            onSwipeReply={handleStartReply}
            onContinue={handleContinue}
            onRetry={handleRetryFromInterrupted}
            onSpeak={speakMessage}
            speakStatus={getSpeakStatus(item.id)}
            continuePending={
              continueMutation.isPending &&
              activeStream?.mode === "continue"
            }
            retryPending={
              streamMutation.isPending && activeStream?.mode === "new"
            }
            imageGenEnabled={imageGenEnabled}
          />
          {showRememberCard && prev ? (
            <RememberCard
              userMessageId={prev.id}
              category={prev.imageCategory ?? "other"}
              onChoose={onRemember}
              isPending={markImageRemembered.isPending}
            />
          ) : null}
        </>
      );
    },
    [handleStartReply, messages, onRemember, markImageRemembered.isPending, speakMessage, getSpeakStatus],
  );

  return (
    <View style={[styles.root, { paddingTop: insets.top }]}>
      <View style={styles.header}>
        <Pressable
          onPress={() => router.back()}
          style={styles.iconBtn}
          accessibilityLabel="Back"
        >
          <Feather name="chevron-left" size={22} color={colors.light.text} />
        </Pressable>
        <Pressable
          style={styles.headerCenter}
          onPress={() => {
            setCustomMode(isPresetMode ? "" : relationshipMode);
            setShowCustomInput(!!relationshipMode && !isPresetMode);
            setRelPickerOpen(true);
          }}
          accessibilityLabel="Change relationship mode"
        >
          <Text style={styles.headerTitle}>{ashleyName}</Text>
          <View style={styles.headerSubtitleRow}>
            <Text
              style={[
                styles.headerSubtitle,
                !relationshipMode && styles.headerSubtitleHint,
              ]}
              numberOfLines={1}
            >
              {subtitleLabel}
            </Text>
            <Feather
              name="chevron-down"
              size={11}
              color={colors.light.mutedForeground}
              style={{ marginLeft: 3 }}
            />
          </View>
        </Pressable>
        <Pressable
          onPress={confirmClear}
          style={styles.iconBtn}
          accessibilityLabel="Clear conversation"
        >
          <Feather name="trash-2" size={18} color={colors.light.mutedForeground} />
        </Pressable>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        // CRITICAL: on Android with behavior="height", KeyboardAvoidingView
        // PERMANENTLY shrinks its own height by `keyboardVerticalOffset` —
        // even when the keyboard is closed. The previous value of
        // `insets.top + 56` (~80px) was leaving a ~80px dead zone below the
        // input bar with the user's latest message hidden behind it. We rely
        // on Android's default windowSoftInputMode=adjustResize (set by Expo)
        // to handle the keyboard — KAV with offset=0 then just adds nothing
        // when keyboard is closed and the natural layout flows correctly.
        keyboardVerticalOffset={Platform.OS === "ios" ? 8 : 0}
        style={{ flex: 1 }}
      >
        {messagesQuery.isLoading ? (
          <View style={styles.center}>
            <ActivityIndicator color={colors.light.primary} />
          </View>
        ) : reversedMessages.length === 0 ? (
          // Empty state lives OUTSIDE the FlatList. Previously this was
          // FlatList's `ListEmptyComponent`, which inherits the parent's
          // inverted transform and renders upside-down — we used to patch
          // it with a manual scaleY:-1 wrapper. That manual flip caused
          // visible glitches on some Android devices (mirrored text, "?"
          // glyphs that didn't update through cache layers). Rendering
          // the empty UI in normal flex flow eliminates ALL flip math.
          <View style={[styles.center, styles.emptyWrap]}>
            <Text style={styles.emptyText}>say something to her</Text>
            <Text style={styles.emptyHint}>
              messages are saved on our server (tied to your Device ID)
              and sent to an AI provider so she can reply
            </Text>
          </View>
        ) : (
          <FlatList
            ref={listRef}
            // Inverted: data[0] (the newest message after `reversedMessages`)
            // anchors to the visually-bottom of the list at scroll offset 0.
            // Cold-mount, keyboard-open, and new-message-arrival all "just
            // work" — no scrollToEnd / scrollToOffset / multi-snap needed.
            // To see older messages the user scrolls UP (WhatsApp-style).
            //
            // FlatList's `inverted` prop auto-counter-flips renderItem rows
            // internally, so message bubbles, icons, and timestamps render
            // upright with NO manual transform. We deliberately do NOT use
            // ListHeaderComponent / ListEmptyComponent / ListFooterComponent
            // here — those slots inherit the parent flip and used to need
            // a manual scaleY:-1 wrapper, which caused mirrored UI bugs.
            // All such "header / empty / signal" content is rendered as
            // siblings BELOW the FlatList in normal flex flow instead.
            inverted
            data={reversedMessages}
            renderItem={renderItem}
            keyExtractor={(m) => m.id}
            contentContainerStyle={styles.list}
            // 20 fills the first viewport on Kane's device; the rest
            // virtualizes lazily as he scrolls up into history.
            initialNumToRender={20}
            // FlatList by default unmounts off-screen rows on Android, which
            // can shift content height. Disable so scroll feels stable.
            removeClippedSubviews={false}
          />
        )}

        {/*
         * Legacy "Ashley is typing…" indicator for the non-streaming
         * retry-unanswered fallback path. Lives OUTSIDE the inverted
         * FlatList so it renders upright with no transform. Placed
         * between the list and the input bar — the same visual slot
         * the old ListHeaderComponent occupied.
         */}
        {(retryUnanswered.isPending ||
          (hasUnansweredTail && !streamMutation.isPending)) ? (
          <View style={[styles.row, styles.rowLeft]}>
            <View
              style={[
                styles.bubble,
                styles.bubbleAshley,
                styles.typingBubble,
              ]}
            >
              <ActivityIndicator
                size="small"
                color={colors.light.mutedForeground}
              />
              <Text style={styles.typingText}>Ashley is typing…</Text>
            </View>
          </View>
        ) : null}

        {/*
         * Adaptive presence signals ("I'm here…", "take your time",
         * "connection dipped…"). Rendered in normal flex flow above
         * the input bar so no counter-flip is needed.
         */}
        <PresenceSignalsList signals={presence.signals} />

        {sendError && !hasUnansweredTail ? (
          <Pressable
            onPress={() => streamMutation.reset()}
            style={styles.errorBanner}
            accessibilityLabel="Dismiss error"
          >
            <Feather
              name="alert-circle"
              size={12}
              color={colors.light.destructiveForeground}
            />
            <Text style={styles.errorText} numberOfLines={6}>
              {sendError}
              {"\n"}
              <Text style={styles.errorSubtext}>
                {classifyError(sendError)} · {process.env.EXPO_PUBLIC_API_BASE ?? process.env.EXPO_PUBLIC_DOMAIN ?? "CONFIG_MISSING"} · tap to dismiss
              </Text>
            </Text>
          </Pressable>
        ) : null}

        {replyingTo ? (
          <View style={styles.replyPreview}>
            <View style={styles.replyAccent} />
            <View style={styles.replyTextWrap}>
              <Text style={styles.replyAuthor}>
                Replying to {replyingTo.role === "ashley" ? "Ashley" : "yourself"}
              </Text>
              <Text style={styles.replyBody} numberOfLines={2}>
                {replyingTo.preview}
              </Text>
            </View>
            <Pressable
              onPress={cancelReply}
              style={styles.replyDismissBtn}
              accessibilityLabel="Cancel reply"
              hitSlop={8}
            >
              <Feather name="x" size={16} color={colors.light.mutedForeground} />
            </Pressable>
          </View>
        ) : null}

        <View style={[styles.inputBar, { paddingBottom: insets.bottom + 8 }]}>
          {imageGenEnabled && (
            <Pressable
              onPress={openImagePicker}
              disabled={streamMutation.isPending || sendImageMutation.isPending}
              style={({ pressed }) => [
                styles.attachBtn,
                (streamMutation.isPending || sendImageMutation.isPending) && {
                  opacity: 0.4,
                },
                pressed && { transform: [{ scale: 0.95 }] },
              ]}
              accessibilityLabel="Attach a photo"
              hitSlop={6}
            >
              <Feather
                name="paperclip"
                size={20}
                color={colors.light.mutedForeground}
              />
            </Pressable>
          )}
          <Pressable
            onPress={openDocumentPicker}
            disabled={
              streamMutation.isPending ||
              sendImageMutation.isPending ||
              docIngestMutation.isPending
            }
            style={({ pressed }) => [
              styles.attachBtn,
              (streamMutation.isPending ||
                sendImageMutation.isPending ||
                docIngestMutation.isPending) && { opacity: 0.4 },
              pressed && { transform: [{ scale: 0.95 }] },
            ]}
            accessibilityLabel="Attach a text document"
            hitSlop={6}
          >
            <Feather
              name="file-text"
              size={20}
              color={colors.light.mutedForeground}
            />
          </Pressable>
          <TextInput
            ref={inputRef}
            value={draft}
            onChangeText={handleDraftChange}
            placeholder={
              replyingTo ? "reply to her..." : "message her..."
            }
            placeholderTextColor={colors.light.mutedForeground}
            style={styles.input}
            multiline
            maxLength={120000}
            // Keep the input editable during streaming so the user
            // can prep their next message while Ashley's mid-reply.
            // (Send is still gated by streamMutation.isPending below.)
            editable={!sendImageMutation.isPending}
            onSubmitEditing={send}
            blurOnSubmit={false}
          />
          <Pressable
            onPressIn={handleMicPressIn}
            onPressOut={handleMicPressOut}
            disabled={
              streamMutation.isPending ||
              sendImageMutation.isPending ||
              transcribeMutation.isPending
            }
            style={({ pressed }) => [
              styles.micBtn,
              voice.state === "recording" && styles.micBtnRecording,
              (streamMutation.isPending ||
                sendImageMutation.isPending ||
                transcribeMutation.isPending) && { opacity: 0.4 },
              pressed && { transform: [{ scale: 0.95 }] },
            ]}
            accessibilityLabel={
              voice.state === "recording"
                ? "Recording — release to send"
                : "Hold to dictate"
            }
            hitSlop={6}
          >
            {transcribeMutation.isPending ? (
              <ActivityIndicator
                size="small"
                color={colors.light.mutedForeground}
              />
            ) : (
              <Feather
                name="mic"
                size={20}
                color={
                  voice.state === "recording"
                    ? colors.light.destructiveForeground
                    : colors.light.mutedForeground
                }
              />
            )}
          </Pressable>
          {activeStream != null ||
          presence.state === "thinking" ||
          presence.state === "speaking" ? (
            // In-place stop button — same slot as send so the tap target
            // never moves under the user's thumb when Ashley starts
            // streaming. Tapping aborts the local SSE controller and
            // fires the server abort endpoint.
            <Pressable
              onPress={handleStop}
              style={({ pressed }) => [
                styles.sendBtn,
                styles.stopBtn,
                pressed && { transform: [{ scale: 0.95 }] },
              ]}
              accessibilityLabel="Stop Ashley"
            >
              <Feather
                name="square"
                size={16}
                color={colors.light.primaryForeground}
              />
            </Pressable>
          ) : (
            <Pressable
              onPress={send}
              disabled={!draft.trim()}
              style={({ pressed }) => [
                styles.sendBtn,
                !draft.trim() && { opacity: 0.4 },
                pressed && { transform: [{ scale: 0.95 }] },
              ]}
              accessibilityLabel="Send message"
            >
              <Feather name="send" size={18} color={colors.light.primaryForeground} />
              {queueSize > 0 ? (
                <View style={styles.queueBadge}>
                  <Text style={styles.queueBadgeText}>{queueSize}</Text>
                </View>
              ) : null}
            </Pressable>
          )}
        </View>
        {voice.state === "recording" ? (
          <View style={styles.voiceStatus} pointerEvents="none">
            <View style={styles.voiceDot} />
            <Text style={styles.voiceStatusText}>
              Listening… {Math.floor(voice.elapsedMs / 1000)}s
            </Text>
          </View>
        ) : transcribeMutation.isPending ? (
          // Stage 2 — show partial transcript live as the model produces
          // text. Shows "Transcribing…" until the first delta arrives,
          // then quotes the running partial so the user can see words
          // appearing instead of staring at a silent spinner.
          <View style={styles.voiceStatus} pointerEvents="none">
            <ActivityIndicator
              size="small"
              color={colors.light.mutedForeground}
            />
            <Text style={styles.voiceStatusText} numberOfLines={2}>
              {voicePartial.length > 0
                ? `“${voicePartial}”`
                : "Transcribing…"}
            </Text>
          </View>
        ) : null}
        {voiceError ? (
          <View style={styles.voiceStatus}>
            <Text style={styles.voiceErrorText}>{voiceError}</Text>
            <Pressable onPress={() => setVoiceError(null)} hitSlop={8}>
              <Feather name="x" size={14} color={colors.light.mutedForeground} />
            </Pressable>
          </View>
        ) : null}

      </KeyboardAvoidingView>

      <Modal
        visible={relPickerOpen}
        transparent
        animationType="fade"
        onRequestClose={() => setRelPickerOpen(false)}
      >
        <Pressable
          style={styles.modalBackdrop}
          onPress={() => setRelPickerOpen(false)}
        >
          <Pressable style={styles.modalCard} onPress={() => {}}>
            <Text style={styles.modalTitle}>Relationship Mode</Text>
            <Text style={styles.modalHint}>
              How Ashley relates to you right now. Change any time — she adapts, no guilt-trips.
            </Text>
            <View style={styles.chipsWrap}>
              {RELATIONSHIP_MODE_PRESETS.map((opt) => {
                const active = opt === relationshipMode;
                return (
                  <Pressable
                    key={opt}
                    onPress={() => applyMode(opt)}
                    style={[styles.chip, active && styles.chipActive]}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        active && styles.chipTextActive,
                      ]}
                    >
                      {opt}
                    </Text>
                  </Pressable>
                );
              })}
              <Pressable
                onPress={() => setShowCustomInput(true)}
                style={[
                  styles.chip,
                  (showCustomInput || (relationshipMode && !isPresetMode)) &&
                    styles.chipActive,
                ]}
              >
                <Text
                  style={[
                    styles.chipText,
                    (showCustomInput || (relationshipMode && !isPresetMode)) &&
                      styles.chipTextActive,
                  ]}
                >
                  Custom
                </Text>
              </Pressable>
            </View>
            {showCustomInput || (relationshipMode && !isPresetMode) ? (
              <>
                <Text style={styles.modalLabel}>your own description</Text>
                <View style={styles.customRow}>
                  <TextInput
                    value={customMode}
                    onChangeText={setCustomMode}
                    placeholder="describe the relationship in your own words"
                    placeholderTextColor={colors.light.mutedForeground}
                    style={styles.customInput}
                    maxLength={80}
                    autoFocus={showCustomInput}
                    returnKeyType="done"
                    onSubmitEditing={() => {
                      if (customMode.trim()) applyMode(customMode);
                    }}
                  />
                  <Pressable
                    onPress={() => {
                      if (customMode.trim()) applyMode(customMode);
                    }}
                    disabled={!customMode.trim() || updateProfile.isPending}
                    style={[
                      styles.customSaveBtn,
                      (!customMode.trim() || updateProfile.isPending) && {
                        opacity: 0.4,
                      },
                    ]}
                  >
                    <Text style={styles.customSaveText}>Save</Text>
                  </Pressable>
                </View>
              </>
            ) : null}
            {relationshipMode ? (
              <Pressable
                onPress={() => applyMode("")}
                style={styles.clearRelBtn}
              >
                <Text style={styles.clearRelText}>clear — no mode set</Text>
              </Pressable>
            ) : null}
          </Pressable>
        </Pressable>
      </Modal>

      <Modal
        visible={!!pickedImage}
        transparent
        animationType="slide"
        onRequestClose={cancelImagePicker}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.imagePickerCard}>
            <View style={styles.imagePickerHeader}>
              <Text style={styles.modalTitle}>Send a photo</Text>
              <Pressable
                onPress={cancelImagePicker}
                hitSlop={8}
                accessibilityLabel="Cancel"
                disabled={sendImageMutation.isPending}
              >
                <Feather
                  name="x"
                  size={20}
                  color={colors.light.mutedForeground}
                />
              </Pressable>
            </View>
            {pickedImage ? (
              pickedExtraImages.length > 0 ? (
                // Multi-image: scrollable strip with per-thumbnail remove button.
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  style={styles.imagePreviewStrip}
                  contentContainerStyle={styles.imagePreviewStripContent}
                >
                  {([pickedImage, ...pickedExtraImages] as Array<{ uri: string }>).map((img, idx) => (
                    <View key={img.uri + String(idx)} style={styles.imagePreviewStripItem}>
                      <Image
                        source={{ uri: img.uri }}
                        style={styles.imagePreviewStripThumb}
                        resizeMode="cover"
                        accessibilityLabel={`Photo ${idx + 1} of ${1 + pickedExtraImages.length}`}
                      />
                      <Pressable
                        onPress={() => removePicked(idx)}
                        disabled={sendImageMutation.isPending}
                        style={styles.imagePreviewRemoveBtn}
                        accessibilityLabel={`Remove photo ${idx + 1}`}
                        hitSlop={4}
                      >
                        <Text style={styles.imagePreviewRemoveX}>✕</Text>
                      </Pressable>
                    </View>
                  ))}
                </ScrollView>
              ) : (
                // Single image: full-width preview with remove button overlay.
                <View style={styles.imagePickerPreviewWrap}>
                  <Image
                    source={{ uri: pickedImage.uri }}
                    style={styles.imagePickerPreview}
                    resizeMode="contain"
                    accessibilityLabel="Selected photo preview"
                  />
                  <Pressable
                    onPress={() => removePicked(0)}
                    disabled={sendImageMutation.isPending}
                    style={styles.imagePickerPreviewRemoveBtn}
                    accessibilityLabel="Remove photo"
                    hitSlop={4}
                  >
                    <Text style={styles.imagePreviewRemoveX}>✕</Text>
                  </Pressable>
                </View>
              )
            ) : null}
            <Text style={styles.modalLabel}>What is this?</Text>
            <View style={styles.chipsWrap}>
              {IMAGE_CATEGORIES.map((c) => {
                const active = c.value === imageCategory;
                return (
                  <Pressable
                    key={c.value}
                    onPress={() => setImageCategory(c.value)}
                    disabled={sendImageMutation.isPending}
                    style={[styles.chip, active && styles.chipActive]}
                  >
                    <Text
                      style={[styles.chipText, active && styles.chipTextActive]}
                    >
                      {c.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={styles.modalLabel}>How should she look at it?</Text>
            <View style={styles.chipsWrap}>
              {IMAGE_MODES.map((m) => {
                const active = m.value === imageMode;
                return (
                  <Pressable
                    key={m.value}
                    onPress={() => setImageMode(m.value)}
                    disabled={sendImageMutation.isPending}
                    style={[styles.chip, active && styles.chipActive]}
                  >
                    <Text
                      style={[styles.chipText, active && styles.chipTextActive]}
                    >
                      {m.label}
                    </Text>
                  </Pressable>
                );
              })}
            </View>
            <Text style={styles.modeHint}>
              {IMAGE_MODES.find((m) => m.value === imageMode)?.hint ?? ""}
            </Text>
            <TextInput
              value={imageCaption}
              onChangeText={setImageCaption}
              placeholder="add a note for her (optional)"
              placeholderTextColor={colors.light.mutedForeground}
              style={styles.imageCaptionInput}
              maxLength={1000}
              multiline
              editable={!sendImageMutation.isPending}
            />
            {imagePickerError ? (
              <Text style={styles.imagePickerError} numberOfLines={3}>
                {imagePickerError}
              </Text>
            ) : null}
            {imageCategory === "medical" ? (
              <Text style={styles.medicalNotice}>
                Heads up: she won't diagnose. She'll help you organise what
                you're seeing and flag NHS 111 / 999 if anything looks
                acute.
              </Text>
            ) : null}
            <Pressable
              onPress={sendPickedImage}
              disabled={sendImageMutation.isPending || !pickedImage}
              style={({ pressed }) => [
                styles.imagePickerSendBtn,
                (sendImageMutation.isPending || !pickedImage) && {
                  opacity: 0.4,
                },
                pressed && { transform: [{ scale: 0.98 }] },
              ]}
              accessibilityLabel="Send the photo"
            >
              {sendImageMutation.isPending ? (
                <ActivityIndicator
                  size="small"
                  color={colors.light.primaryForeground}
                />
              ) : (
                <>
                  <Feather
                    name="send"
                    size={16}
                    color={colors.light.primaryForeground}
                  />
                  <Text style={styles.imagePickerSendText}>
                    Send to {ashleyName}
                  </Text>
                </>
              )}
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
}

// ---------------------------------------------------------------------------
// "Should I remember anything?" card — appears under Ashley's reply to a
// user-uploaded image while the user hasn't decided yet. Three options:
// keep it as a memory, keep it as a visual reference (lighter weight), or
// dismiss the card. Tapping any option clears the card immediately.
// ---------------------------------------------------------------------------

function RememberCard({
  userMessageId,
  category,
  onChoose,
  isPending,
}: {
  userMessageId: string;
  category: ImageCategory;
  onChoose: (
    id: string,
    decision: "remember" | "visual" | "dismiss",
  ) => void;
  isPending: boolean;
}): React.JSX.Element {
  return (
    <View style={[styles.row, styles.rowLeft]}>
      <View style={styles.rememberCard}>
        <View style={styles.rememberHeader}>
          <Feather
            name="bookmark"
            size={14}
            color={colors.light.accent}
          />
          <Text style={styles.rememberHeaderText}>
            Should I remember anything?
          </Text>
        </View>
        <Text style={styles.rememberHint}>
          {category === "ashley_identity"
            ? "I can hold this as part of how I see myself."
            : category === "medical"
              ? "I can keep this so I can refer back to it next time."
              : "I can keep this in mind for next time we talk."}
        </Text>
        <View style={styles.rememberRow}>
          <Pressable
            onPress={() => onChoose(userMessageId, "remember")}
            disabled={isPending}
            style={({ pressed }) => [
              styles.rememberBtn,
              styles.rememberBtnPrimary,
              isPending && { opacity: 0.4 },
              pressed && { transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={styles.rememberBtnPrimaryText}>Remember</Text>
          </Pressable>
          <Pressable
            onPress={() => onChoose(userMessageId, "visual")}
            disabled={isPending}
            style={({ pressed }) => [
              styles.rememberBtn,
              styles.rememberBtnSecondary,
              isPending && { opacity: 0.4 },
              pressed && { transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={styles.rememberBtnSecondaryText}>Just visual</Text>
          </Pressable>
          <Pressable
            onPress={() => onChoose(userMessageId, "dismiss")}
            disabled={isPending}
            style={({ pressed }) => [
              styles.rememberBtn,
              styles.rememberBtnGhost,
              isPending && { opacity: 0.4 },
              pressed && { transform: [{ scale: 0.97 }] },
            ]}
          >
            <Text style={styles.rememberBtnGhostText}>Skip</Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}

function MessageBubble({
  message,
  onSwipeReply,
  onContinue,
  onRetry,
  onSpeak,
  speakStatus,
  continuePending,
  retryPending,
  imageGenEnabled = true,
}: {
  message: Message;
  onSwipeReply: (m: Message) => void;
  onContinue?: (interruptedMessageId: string) => void;
  onRetry?: (interruptedMessageId: string) => void;
  onSpeak?: (messageId: string, text: string) => void;
  speakStatus?: SpeakStatus;
  continuePending?: boolean;
  retryPending?: boolean;
  /**
   * When false, suppress all pending-selfie UI and retry buttons.
   * Existing resolved imageUrl photos are not affected (they already
   * arrived and are part of the conversation history).
   */
  imageGenEnabled?: boolean;
}): React.JSX.Element {
  const isUser = message.role === "user";
  const hasImage = !!message.imageUrl;
  const hasText = !!message.content && message.content.trim().length > 0;
  const [imageFailed, setImageFailed] = useState(false);
  /** Multi-image gallery: resolved imageUrls array from a visual packet. */
  const hasGallery = !!(message.imageUrls && message.imageUrls.length > 1);
  // When a multi-image gallery is present, suppress the single-image block so
  // the packet renders only as a gallery group — not as single image + gallery.
  const showImage = hasImage && !imageFailed && !hasGallery;
  // Full-screen image viewer state. Tap the preview to open; modal renders
  // the SAME imageUrl with resizeMode="contain" so we can tell whether the
  // generator cropped the source vs whether the chat preview is hiding part
  // of it. naturalDims is captured from the preview's onLoad event and shown
  // in the viewer's debug bar — Wren needs it to confirm raw dims.
  const [viewerOpen, setViewerOpen] = useState(false);
  /** When a gallery thumb is tapped, this holds the URL to show in the viewer. */
  const [galleryViewerUrl, setGalleryViewerUrl] = useState<string | null>(null);
  /** Index of the currently visible slide in the gallery viewer. */
  const [galleryViewerIndex, setGalleryViewerIndex] = useState(0);
  const galleryScrollRef = useRef<ScrollView>(null);
  const { width: screenWidth } = useWindowDimensions();
  // When the gallery viewer opens, scroll to the tapped slide without animation.
  useEffect(() => {
    if (viewerOpen && hasGallery) {
      const t = setTimeout(() => {
        galleryScrollRef.current?.scrollTo({
          x: galleryViewerIndex * screenWidth,
          animated: false,
        });
      }, 50);
      return () => clearTimeout(t);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewerOpen]);
  const [imageNaturalDims, setImageNaturalDims] = useState<{
    width: number;
    height: number;
  } | null>(null);
  // Safe-area inset for the viewer toolbar (avoids overlap with the status
  // bar / dynamic island when statusBarTranslucent is on).
  const bubbleInsets = useSafeAreaInsets();

  // selfieVibe is set by the server when Ashley wanted to send a photo.
  // While the background generation is still running (or after it failed),
  // imageUrl is null and selfieVibe is the prompt. We use this to drive
  // either a "taking a selfie…" pending state or a retry button.
  // Gate: when image generation is disabled, treat any pending vibe as null
  // so no "taking a selfie…" spinner or retry button appears.
  const pendingSelfieVibe =
    imageGenEnabled && !hasImage && message.selfieVibe ? message.selfieVibe : null;
  const { retry } = useRetrySelfie();
  const autoInFlight = useSelfieInFlight(message.id);
  // Track retry state locally with React state so the spinner / error
  // message actually trigger re-renders. (The hook's underlying dedup Set
  // isn't reactive — that was the old bug where tapping looked dead.)
  const [retryingThis, setRetryingThis] = useState(false);
  const [retryError, setRetryError] = useState<string | null>(null);
  // Guard against setting state after the bubble unmounts. The selfie
  // poll can run for up to 2 minutes, and the user might clear the chat
  // or navigate away mid-flight.
  const isMountedRef = useRef(true);
  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);
  const onCopyText = useCallback(async () => {
    if (!hasText) return;
    try {
      await Clipboard.setStringAsync(message.content);
      Alert.alert("Copied", "Message copied to clipboard.");
    } catch {
      Alert.alert("Couldn't copy", "Try again in a moment.");
    }
  }, [hasText, message.content]);

  const onCopyImageUrl = useCallback(async () => {
    const activeUrl = galleryViewerUrl ?? message.imageUrl;
    if (!activeUrl) return;
    try {
      await Clipboard.setStringAsync(activeUrl);
      console.log("[chat] copied raw image URL", activeUrl);
      Alert.alert("URL copied", "Open it in a browser to inspect the raw image.");
    } catch {
      Alert.alert("Couldn't copy", "Try again in a moment.");
    }
  }, [galleryViewerUrl, message.imageUrl]);

  const onImageLongPress = useCallback(() => {
    if (!message.imageUrl) return;
    Alert.alert(
      "Image options",
      message.imageUrl,
      [
        { text: "Open full screen", onPress: () => setViewerOpen(true) },
        { text: "Copy raw URL", onPress: () => void onCopyImageUrl() },
        { text: "Save to library", onPress: () => void onSaveImage() },
        { text: "Cancel", style: "cancel" },
      ],
      { cancelable: true },
    );
  // onSaveImage is stable — defined below; eslint-disable to allow forward ref.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [message.imageUrl, onCopyImageUrl]);

  const onSaveImage = useCallback(async () => {
    const activeUrl = galleryViewerUrl ?? message.imageUrl;
    if (!activeUrl) return;
    try {
      const perm = await MediaLibrary.requestPermissionsAsync();
      if (!perm.granted) {
        Alert.alert(
          "Permission needed",
          "Allow photo library access to save Ashley's selfies.",
        );
        return;
      }
      const target =
        (FileSystem.cacheDirectory ?? "") +
        `ashley-${message.id}.jpg`;
      const dl = await FileSystem.downloadAsync(activeUrl, target);
      await MediaLibrary.saveToLibraryAsync(dl.uri);
      Alert.alert("Saved", "Photo saved to your library.");
    } catch (err) {
      Alert.alert(
        "Couldn't save",
        err instanceof Error && err.message
          ? err.message
          : "Something went wrong saving the photo.",
      );
    }
  }, [galleryViewerUrl, message.id, message.imageUrl]);

  const onRetrySelfie = useCallback(() => {
    if (!pendingSelfieVibe || retryingThis) return;
    setRetryingThis(true);
    setRetryError(null);
    retry(message.id, pendingSelfieVibe)
      .catch((err: unknown) => {
        if (!isMountedRef.current) return;
        setRetryError(
          err instanceof Error && err.message
            ? err.message
            : "still couldn't reach her — tap again",
        );
      })
      .finally(() => {
        if (!isMountedRef.current) return;
        setRetryingThis(false);
      });
  }, [retry, message.id, pendingSelfieVibe, retryingThis]);

  // User bubbles sit on the right and reveal the reply hint by being
  // dragged left; Ashley bubbles do the opposite. Mirrors iMessage.
  const swipeDirection: "left" | "right" = isUser ? "left" : "right";
  const handleSwipe = useCallback(() => {
    onSwipeReply(message);
  }, [onSwipeReply, message]);

  const quoted = message.replyTo;

  const bubbleContent = (
    <View style={[styles.row, isUser ? styles.rowRight : styles.rowLeft]}>
      <View
        style={[
          styles.bubble,
          isUser ? styles.bubbleUser : styles.bubbleAshley,
          (showImage || pendingSelfieVibe || hasGallery) && styles.bubbleWithImage,
          quoted && styles.bubbleWithQuote,
        ]}
      >
        {quoted ? (
          <View
            style={[
              styles.quotedHeader,
              isUser ? styles.quotedHeaderUser : styles.quotedHeaderAshley,
            ]}
          >
            <View
              style={[
                styles.quotedAccent,
                isUser
                  ? styles.quotedAccentUser
                  : styles.quotedAccentAshley,
              ]}
            />
            <View style={styles.quotedTextWrap}>
              <Text
                style={[
                  styles.quotedAuthor,
                  isUser
                    ? styles.quotedAuthorUser
                    : styles.quotedAuthorAshley,
                ]}
              >
                {quoted.role === "ashley" ? "Ashley" : "You"}
              </Text>
              <Text
                style={[
                  styles.quotedBody,
                  isUser ? styles.quotedBodyUser : styles.quotedBodyAshley,
                ]}
                numberOfLines={2}
              >
                {quoted.preview}
              </Text>
            </View>
          </View>
        ) : null}
        {showImage ? (
          <>
            {/*
              Tap-to-enlarge wiring (Wren May 2026 follow-up #4 — hardened
              for Android). Layout: a bounded View carrying the explicit
              240×320 hit box, a Pressable filling that box with
              android_ripple for visible tap feedback, the Image inside
              with pointerEvents="none" so the Image never swallows the
              tap, and an absolute-positioned "expand" icon overlay in the
              top-right corner so the tap target is visually obvious. The
              second Pressable sitting on top of the icon is a redundant
              hit area for users who tap the affordance directly.
            */}
            <View
              style={styles.bubbleImageHitBox}
              accessibilityLabel="Image from Ashley"
            >
              <Pressable
                onPress={() => {
                  console.log("[chat] image preview tapped — opening viewer", {
                    component: "MessageBubble.preview",
                    imageUrl: message.imageUrl,
                    previewWidth: 240,
                    previewHeight: 320,
                    previewResizeMode: "contain",
                    naturalWidth: imageNaturalDims?.width ?? null,
                    naturalHeight: imageNaturalDims?.height ?? null,
                    tapHandlerAttached: true,
                  });
                  setViewerOpen(true);
                }}
                onLongPress={onImageLongPress}
                delayLongPress={350}
                android_ripple={{
                  color: "rgba(255,255,255,0.18)",
                  borderless: false,
                }}
                style={({ pressed }) => [
                  styles.bubbleImagePressable,
                  pressed && { opacity: 0.85 },
                ]}
                accessibilityRole="button"
                accessibilityLabel="Tap to view full screen, long-press for options"
                accessibilityHint="Opens a full-screen viewer with contain scaling"
              >
                <Image
                  source={{ uri: message.imageUrl! }}
                  style={styles.bubbleImage}
                  resizeMode="contain"
                  accessibilityLabel="Image from Ashley"
                  onLoad={(e) => {
                    const src = e?.nativeEvent?.source;
                    if (src && typeof src.width === "number" && typeof src.height === "number") {
                      setImageNaturalDims({ width: src.width, height: src.height });
                      console.log("[chat] image preview loaded", {
                        component: "MessageBubble.preview",
                        imageUrl: message.imageUrl,
                        naturalWidth: src.width,
                        naturalHeight: src.height,
                        previewWidth: 240,
                        previewHeight: 320,
                        previewResizeMode: "contain",
                        tapHandlerAttached: true,
                        tapHardenedBuild: "feet-followup-4",
                      });
                    }
                  }}
                  onError={(e) => {
                    console.warn(
                      "[chat] selfie image failed to load",
                      message.imageUrl,
                      e?.nativeEvent,
                    );
                    setImageFailed(true);
                  }}
                />
                <View style={styles.bubbleImageExpandBadge} pointerEvents="none">
                  <Text style={styles.bubbleImageExpandIcon}>⤢</Text>
                </View>
              </Pressable>
            </View>
            <Pressable
              onPress={() => {
                console.log("[chat] tap-to-enlarge pill pressed", {
                  imageUrl: message.imageUrl,
                });
                setViewerOpen(true);
              }}
              hitSlop={8}
              style={({ pressed }) => [
                styles.tapToEnlargePill,
                pressed && { opacity: 0.7 },
              ]}
              accessibilityRole="button"
              accessibilityLabel="Open image full screen"
            >
              <Text style={[styles.bubbleImageExpandIcon, { fontSize: 11, color: colors.light.mutedForeground }]}>⤢</Text>
              <Text style={styles.tapToEnlargePillText}>Tap to enlarge</Text>
            </Pressable>
          </>
        ) : null}
        {/*
          Full-screen viewer modal — shared by single-image and multi-image
          gallery paths. Rendered unconditionally (outside the showImage branch)
          so gallery thumbnail taps (which set viewerOpen + galleryViewerUrl)
          can open it even when hasGallery=true suppresses the single-image block.
          galleryViewerUrl takes priority; falls back to message.imageUrl for
          the single-image case.
        */}
        {(showImage || hasGallery) && (viewerOpen || galleryViewerUrl) ? (
          <Modal
            visible={viewerOpen}
            transparent
            animationType="fade"
            onRequestClose={() => { setViewerOpen(false); setGalleryViewerUrl(null); }}
            statusBarTranslucent
          >
            <View style={styles.viewerBackdrop}>
              <Pressable
                style={styles.viewerDismissArea}
                onPress={() => { setViewerOpen(false); setGalleryViewerUrl(null); }}
                accessibilityLabel="Tap to close full-screen viewer"
              />
              {hasGallery ? (
                // Swipeable paginated gallery — one slide per image.
                <ScrollView
                  ref={galleryScrollRef}
                  horizontal
                  pagingEnabled
                  showsHorizontalScrollIndicator={false}
                  style={{ flex: 1 }}
                  onMomentumScrollEnd={(e) => {
                    const idx = Math.round(
                      e.nativeEvent.contentOffset.x / screenWidth,
                    );
                    const urls = message.imageUrls ?? [];
                    const url = urls[idx];
                    if (url !== undefined) {
                      setGalleryViewerIndex(idx);
                      setGalleryViewerUrl(url);
                    }
                  }}
                >
                  {(message.imageUrls ?? []).map((url, idx) => (
                    <View
                      key={url ? url + idx : `failed-${idx}`}
                      style={{
                        width: screenWidth,
                        flex: 1,
                        justifyContent: "center",
                      }}
                    >
                      {url ? (
                        <Image
                          source={{ uri: url }}
                          style={[styles.viewerImage, { width: screenWidth }]}
                          resizeMode="contain"
                          accessibilityLabel={`Photo ${idx + 1} of ${(message.imageUrls ?? []).length}`}
                        />
                      ) : (
                        <View
                          style={{
                            flex: 1,
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          <Feather
                            name="image"
                            size={40}
                            color="rgba(255,255,255,0.3)"
                          />
                        </View>
                      )}
                    </View>
                  ))}
                </ScrollView>
              ) : (
                // Single-image viewer — unchanged path.
                <Image
                  source={{ uri: message.imageUrl! }}
                  style={styles.viewerImage}
                  resizeMode="contain"
                  accessibilityLabel="Full-screen image — entire frame visible"
                  onLoad={(e) => {
                    const src = e?.nativeEvent?.source;
                    if (src) {
                      console.log("[chat] full-screen viewer loaded image", {
                        imageUrl: message.imageUrl,
                        naturalWidth: src.width,
                        naturalHeight: src.height,
                        viewerResizeMode: "contain",
                      });
                    }
                  }}
                />
              )}
              {/* Page-indicator dots for multi-image packets. */}
              {hasGallery && (message.imageUrls ?? []).length > 1 ? (
                <View style={styles.viewerDots} pointerEvents="none">
                  {(message.imageUrls ?? []).map((_, idx) => (
                    <View
                      key={idx}
                      style={[
                        styles.viewerDot,
                        galleryViewerIndex === idx && styles.viewerDotActive,
                      ]}
                    />
                  ))}
                </View>
              ) : null}
              <View
                style={[styles.viewerToolbar, { top: bubbleInsets.top + 8 }]}
                pointerEvents="box-none"
              >
                <Pressable
                  onPress={() => { setViewerOpen(false); setGalleryViewerUrl(null); }}
                  style={styles.viewerToolbarBtn}
                  hitSlop={12}
                  accessibilityLabel="Close viewer"
                >
                  <Feather name="x" size={22} color="#fff" />
                </Pressable>
                <View style={{ flex: 1 }} />
                <Pressable
                  onPress={onCopyImageUrl}
                  style={styles.viewerToolbarBtn}
                  hitSlop={12}
                  accessibilityLabel="Copy raw image URL"
                >
                  <Feather name="copy" size={20} color="#fff" />
                </Pressable>
                <Pressable
                  onPress={onSaveImage}
                  style={styles.viewerToolbarBtn}
                  hitSlop={12}
                  accessibilityLabel="Save image to library"
                >
                  <Feather name="download" size={20} color="#fff" />
                </Pressable>
              </View>
              <View style={styles.viewerDebugBar} pointerEvents="box-none">
                <Text style={styles.viewerDebugText} numberOfLines={2}>
                  {imageNaturalDims
                    ? `raw ${imageNaturalDims.width}×${imageNaturalDims.height} · contain`
                    : "raw dims pending · contain"}
                </Text>
                <Text style={styles.viewerDebugUrl} numberOfLines={1} selectable>
                  {galleryViewerUrl ?? message.imageUrl}
                </Text>
              </View>
            </View>
          </Modal>
        ) : null}
        {hasGallery ? (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            style={styles.galleryRow}
            contentContainerStyle={styles.galleryRowContent}
          >
            {(message.imageUrls ?? []).map((uri, idx) =>
              uri ? (
                <Pressable
                  key={uri + idx}
                  onPress={() => {
                    setGalleryViewerIndex(idx);
                    setGalleryViewerUrl(uri);
                    setViewerOpen(true);
                  }}
                  accessibilityRole="button"
                  accessibilityLabel={`Open photo ${idx + 1} of ${(message.imageUrls ?? []).length} full screen`}
                >
                  <View style={styles.galleryThumb}>
                    <Image
                      source={{ uri }}
                      style={styles.galleryThumbImage}
                      resizeMode="cover"
                      accessibilityLabel={`Photo ${idx + 1} of ${(message.imageUrls ?? []).length}`}
                    />
                  </View>
                </Pressable>
              ) : (
                // Failed generation slot — preserve position, show error tile.
                <View
                  key={`failed-${idx}`}
                  style={[styles.galleryThumb, styles.galleryThumbFailed]}
                  accessibilityLabel={`Photo ${idx + 1} failed to generate`}
                >
                  <Feather name="image" size={22} color={colors.light.mutedForeground} />
                </View>
              )
            )}
          </ScrollView>
        ) : null}
        {imageFailed ? (
          <View style={styles.imageError}>
            <Feather
              name="image"
              size={18}
              color={colors.light.mutedForeground}
            />
            <Text style={styles.imageErrorText}>
              couldn't load her photo — tap to retry?
            </Text>
            <Pressable
              onPress={() => setImageFailed(false)}
              style={styles.imageRetryBtn}
              accessibilityLabel="Retry loading photo"
            >
              <Feather
                name="refresh-cw"
                size={14}
                color={colors.light.text}
              />
            </Pressable>
          </View>
        ) : null}
        {pendingSelfieVibe && !showImage && !imageFailed && !hasGallery ? (
          (() => {
            const generating = retryingThis || autoInFlight;
            return (
              <Pressable
                onPress={generating ? undefined : onRetrySelfie}
                disabled={generating}
                hitSlop={8}
                style={styles.selfiePending}
                accessibilityLabel={
                  generating ? "Taking a selfie" : "Tap to retry sending photo"
                }
              >
                {generating ? (
                  <ActivityIndicator
                    size="small"
                    color={colors.light.mutedForeground}
                  />
                ) : (
                  <Feather
                    name="camera"
                    size={18}
                    color={colors.light.mutedForeground}
                  />
                )}
                <Text style={styles.selfiePendingText} numberOfLines={2}>
                  {generating
                    ? "taking a selfie…"
                    : retryError
                      ? retryError
                      : "couldn't send the photo — tap to retry"}
                </Text>
              </Pressable>
            );
          })()
        ) : null}
        {hasText ? (
          <Text
            selectable
            onLongPress={onCopyText}
            style={[
              styles.bubbleText,
              isUser ? styles.bubbleUserText : styles.bubbleAshleyText,
              (showImage || pendingSelfieVibe) && styles.bubbleTextWithImage,
            ]}
          >
            {message.content}
            {message.status === "streaming" && message.role === "ashley" ? (
              <StreamingCursor color={colors.light.bubbleAshleyText} />
            ) : null}
          </Text>
        ) : message.status === "streaming" && message.role === "ashley" ? (
          // Empty Ashley bubble that just opened — render the cursor
          // alone so the user sees something the instant the optimistic
          // row lands, before the first delta arrives.
          <Text
            style={[
              styles.bubbleText,
              styles.bubbleAshleyText,
            ]}
          >
            <StreamingCursor color={colors.light.bubbleAshleyText} />
          </Text>
        ) : null}
        {message.role === "ashley" && hasText && message.status !== "streaming" && message.status !== "interrupted" ? (
          <Pressable
            onPress={() => onSpeak?.(message.id, message.content)}
            disabled={speakStatus === "loading"}
            style={({ pressed }) => [
              styles.speakBtn,
              speakStatus === "loading" && { opacity: 0.5 },
              pressed && { opacity: 0.6 },
            ]}
            hitSlop={8}
            accessibilityLabel="Speak this message"
          >
            {speakStatus === "loading" ? (
              <ActivityIndicator size="small" color={colors.light.mutedForeground} />
            ) : (
              <Feather
                name={speakStatus === "error" ? "alert-circle" : "volume-2"}
                size={12}
                color={
                  speakStatus === "error"
                    ? colors.light.destructiveForeground
                    : colors.light.mutedForeground
                }
              />
            )}
            <Text style={styles.speakBtnText}>
              {speakStatus === "loading"
                ? "loading…"
                : speakStatus === "error"
                  ? "retry"
                  : "Speak"}
            </Text>
          </Pressable>
        ) : null}
        {message.status === "interrupted" && message.role === "ashley" ? (
          // Recovery actions sit beneath the partial text. Continue is
          // the primary action — same colour as the send button — and
          // Retry is the secondary, ghost-buttoned action.
          <View style={styles.interruptedActions}>
            <Pressable
              onPress={() => onContinue?.(message.id)}
              disabled={!!continuePending || !!retryPending || !isApiConfigured}
              style={({ pressed }) => [
                styles.continueBtn,
                (continuePending || retryPending) && { opacity: 0.5 },
                pressed && { transform: [{ scale: 0.97 }] },
              ]}
              accessibilityLabel="Continue from where she paused"
              hitSlop={6}
            >
              {continuePending ? (
                <ActivityIndicator
                  size="small"
                  color={colors.light.primaryForeground}
                />
              ) : (
                <>
                  <Feather
                    name="play"
                    size={11}
                    color={colors.light.primaryForeground}
                  />
                  <Text style={styles.continueBtnText}>Continue</Text>
                </>
              )}
            </Pressable>
            <Pressable
              onPress={() => onRetry?.(message.id)}
              disabled={!!continuePending || !!retryPending}
              style={({ pressed }) => [
                styles.retryBtn,
                (continuePending || retryPending) && { opacity: 0.5 },
                pressed && { transform: [{ scale: 0.97 }] },
              ]}
              accessibilityLabel="Retry from the start"
              hitSlop={6}
            >
              {retryPending ? (
                <ActivityIndicator
                  size="small"
                  color={colors.light.mutedForeground}
                />
              ) : (
                <>
                  <Feather
                    name="refresh-cw"
                    size={11}
                    color={colors.light.mutedForeground}
                  />
                  <Text style={styles.retryBtnText}>Retry</Text>
                </>
              )}
            </Pressable>
          </View>
        ) : null}
      </View>
    </View>
  );

  return (
    <SwipeToReply direction={swipeDirection} onTrigger={handleSwipe}>
      {bubbleContent}
    </SwipeToReply>
  );
}

/**
 * Pulsing block-cursor rendered at the end of an in-flight Ashley
 * bubble. Lives at module scope so its useEffect runs once per mount
 * (re-renders of the parent bubble don't restart the loop).
 */
function StreamingCursor({ color }: { color: string }): React.JSX.Element {
  const opacity = useRef(new Animated.Value(1)).current;
  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(opacity, {
          toValue: 0.25,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(opacity, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [opacity]);
  return (
    <Animated.Text style={[styles.cursor, { color, opacity }]}>
      {"▍"}
    </Animated.Text>
  );
}

/**
 * Renders the adaptive presence signals — "I'm here…", "take your
 * time", "connection dipped…" — as small italic rows under the latest
 * message. Each row fades in on mount and is removed by the dismiss
 * timer in `usePresenceLoop`.
 */
function PresenceSignalsList({
  signals,
}: {
  signals: PresenceSignal[];
}): React.JSX.Element | null {
  if (signals.length === 0) return null;
  return (
    <View style={styles.signalsContainer}>
      {signals.map((sig) => (
        <PresenceSignalRow key={sig.key} signal={sig} />
      ))}
    </View>
  );
}

function PresenceSignalRow({
  signal,
}: {
  signal: PresenceSignal;
}): React.JSX.Element {
  const opacity = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(opacity, {
      toValue: 1,
      duration: 250,
      useNativeDriver: true,
    }).start();
  }, [opacity]);
  return (
    <Animated.View style={[styles.signalRow, { opacity }]}>
      <Text style={styles.signalText}>{signal.message}</Text>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.light.background,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.light.border,
  },
  headerCenter: { flex: 1, alignItems: "center" },
  headerSubtitleRow: { flexDirection: "row", alignItems: "center", marginTop: 1 },
  headerSubtitleHint: { fontStyle: "italic", opacity: 0.85 },
  modalBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.55)",
    justifyContent: "flex-end",
  },
  modalCard: {
    backgroundColor: colors.light.background,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 28,
    gap: 10,
  },
  modalTitle: {
    color: colors.light.text,
    fontFamily: "Inter_600SemiBold",
    fontSize: 17,
  },
  modalHint: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    marginBottom: 4,
  },
  modalLabel: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    marginTop: 8,
  },
  chipsWrap: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: colors.light.muted,
  },
  chipActive: {
    backgroundColor: colors.light.primary,
  },
  chipText: {
    color: colors.light.text,
    fontFamily: "Inter_500Medium",
    fontSize: 13,
  },
  chipTextActive: {
    color: colors.light.primaryForeground,
  },
  customRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  customInput: {
    flex: 1,
    backgroundColor: colors.light.muted,
    color: colors.light.text,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
  },
  customSaveBtn: {
    backgroundColor: colors.light.primary,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 12,
  },
  customSaveText: {
    color: colors.light.primaryForeground,
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  clearRelBtn: {
    alignSelf: "center",
    paddingVertical: 8,
    marginTop: 4,
  },
  clearRelText: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    textDecorationLine: "underline",
  },
  headerTitle: {
    color: colors.light.text,
    fontFamily: "Inter_600SemiBold",
    fontSize: 17,
  },
  headerSubtitle: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 11,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  list: {
    paddingHorizontal: 14,
    paddingVertical: 12,
    flexGrow: 1,
  },
  row: {
    flexDirection: "row",
    marginVertical: 4,
  },
  rowLeft: { justifyContent: "flex-start" },
  rowRight: { justifyContent: "flex-end" },
  bubble: {
    maxWidth: "80%",
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 18,
  },
  bubbleWithQuote: {
    // Quoted reply previews need horizontal room or the inner Text wraps
    // character-by-character when the user's own message is very short
    // (e.g. just "?"), producing a bizarre tall narrow bubble. Force a
    // sensible floor; maxWidth still caps the upper bound.
    minWidth: 220,
  },
  bubbleUser: {
    backgroundColor: colors.light.bubbleUser,
    borderBottomRightRadius: 6,
  },
  bubbleAshley: {
    backgroundColor: colors.light.bubbleAshley,
    borderBottomLeftRadius: 6,
  },
  bubbleText: {
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    lineHeight: 21,
  },
  bubbleUserText: { color: colors.light.bubbleUserText },
  bubbleAshleyText: { color: colors.light.bubbleAshleyText },
  bubbleWithImage: {
    paddingHorizontal: 4,
    paddingTop: 4,
    paddingBottom: 6,
    overflow: "hidden",
  },
  galleryRow: {
    paddingVertical: 4,
  },
  galleryRowContent: {
    flexDirection: "row",
    gap: 4,
    paddingHorizontal: 2,
  },
  galleryThumb: {
    width: 114,
    height: 114,
    borderRadius: 10,
    overflow: "hidden",
    backgroundColor: "rgba(0,0,0,0.12)",
  },
  galleryThumbFailed: {
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0,0,0,0.18)",
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.08)",
  },
  galleryThumbImage: {
    width: 114,
    height: 114,
  },
  bubbleImageHitBox: {
    width: 240,
    height: 320,
    borderRadius: 14,
    overflow: "hidden",
  },
  bubbleImagePressable: {
    width: 240,
    height: 320,
    position: "relative",
  },
  bubbleImage: {
    width: 240,
    height: 320,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.2)",
  },
  bubbleImageExpandBadge: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.55)",
    alignItems: "center",
    justifyContent: "center",
  },
  bubbleImageExpandIcon: {
    fontSize: 14,
    color: "#fff",
    includeFontPadding: false,
  },
  tapToEnlargePill: {
    alignSelf: "flex-start",
    marginLeft: 4,
    marginTop: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.06)",
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  tapToEnlargePillText: {
    color: colors.light.mutedForeground,
    fontSize: 11,
    fontWeight: "500",
  },
  // Full-screen viewer (per Wren May 2026 #3): black backdrop, contain-scaled
  // image, toolbar with close/copy-url/save, debug bar showing raw dims + URL.
  viewerBackdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.96)",
    alignItems: "center",
    justifyContent: "center",
  },
  viewerDismissArea: {
    ...StyleSheet.absoluteFillObject,
  },
  viewerImage: {
    width: "100%",
    height: "100%",
  },
  viewerDots: {
    position: "absolute",
    bottom: 36,
    left: 0,
    right: 0,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 6,
  },
  viewerDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: "rgba(255,255,255,0.35)",
  },
  viewerDotActive: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#fff",
  },
  viewerToolbar: {
    position: "absolute",
    top: 40,
    left: 0,
    right: 0,
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 12,
    gap: 8,
  },
  viewerToolbarBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0,0,0,0.55)",
    alignItems: "center",
    justifyContent: "center",
  },
  viewerDebugBar: {
    position: "absolute",
    bottom: 24,
    left: 12,
    right: 12,
    backgroundColor: "rgba(0,0,0,0.6)",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  viewerDebugText: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 2,
  },
  viewerDebugUrl: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 11,
  },
  bubbleTextWithImage: {
    paddingHorizontal: 10,
    paddingTop: 8,
    paddingBottom: 2,
  },
  imageError: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
  },
  imageErrorText: {
    flex: 1,
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    fontStyle: "italic",
  },
  imageRetryBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: colors.light.muted,
  },
  selfiePending: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 14,
    width: 240,
    borderRadius: 14,
    backgroundColor: "rgba(255,255,255,0.04)",
  },
  selfiePendingText: {
    flex: 1,
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    fontStyle: "italic",
  },
  replyPreview: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "rgba(122, 92, 255, 0.12)",
    borderTopWidth: 1,
    borderTopColor: colors.light.border,
  },
  replyAccent: {
    width: 3,
    alignSelf: "stretch",
    borderRadius: 2,
    backgroundColor: colors.light.accent,
  },
  replyTextWrap: { flex: 1, gap: 2 },
  replyAuthor: {
    color: colors.light.accent,
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
  },
  replyBody: {
    color: colors.light.text,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    opacity: 0.85,
  },
  replyDismissBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  quotedHeader: {
    flexDirection: "row",
    gap: 8,
    paddingVertical: 6,
    paddingHorizontal: 8,
    borderRadius: 10,
    marginBottom: 6,
  },
  quotedHeaderUser: {
    backgroundColor: "rgba(0,0,0,0.18)",
  },
  quotedHeaderAshley: {
    backgroundColor: "rgba(122, 92, 255, 0.18)",
  },
  quotedAccent: {
    width: 2,
    alignSelf: "stretch",
    borderRadius: 1,
  },
  quotedAccentUser: { backgroundColor: "rgba(26,19,37,0.6)" },
  quotedAccentAshley: { backgroundColor: colors.light.accent },
  quotedTextWrap: { flex: 1, gap: 2 },
  quotedAuthor: {
    fontFamily: "Inter_600SemiBold",
    fontSize: 11,
  },
  quotedAuthorUser: { color: "rgba(26,19,37,0.85)" },
  quotedAuthorAshley: { color: colors.light.accent },
  quotedBody: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  quotedBodyUser: { color: "rgba(26,19,37,0.75)" },
  quotedBodyAshley: { color: "rgba(245,232,216,0.85)" },
  emptyWrap: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 32,
    gap: 8,
  },
  emptyText: {
    color: colors.light.text,
    fontFamily: "Inter_500Medium",
    fontSize: 16,
    textAlign: "center",
  },
  emptyHint: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    textAlign: "center",
  },
  typingBubble: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  typingText: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 13,
    fontStyle: "italic",
  },
  errorBanner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: colors.light.destructive,
  },
  errorText: {
    color: colors.light.destructiveForeground,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    flex: 1,
  },
  errorSubtext: {
    color: colors.light.destructiveForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 10,
    opacity: 0.85,
  },
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingHorizontal: 12,
    paddingTop: 8,
    gap: 8,
    borderTopWidth: 1,
    borderTopColor: colors.light.border,
    backgroundColor: colors.light.background,
  },
  input: {
    flex: 1,
    color: colors.light.text,
    backgroundColor: colors.light.muted,
    borderRadius: 22,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 10,
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    maxHeight: 140,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.light.primary,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },
  // The stop variant inherits sendBtn's footprint so the in-place
  // swap doesn't cause layout shift. Just a hue change to signal the
  // destructive intent.
  stopBtn: {
    backgroundColor: colors.light.destructive,
  },
  // Small count bubble that overlays the send button while messages are queued.
  queueBadge: {
    position: "absolute",
    top: -5,
    right: -5,
    minWidth: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: colors.light.destructive,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 3,
  },
  queueBadgeText: {
    fontFamily: "Inter_700Bold",
    fontSize: 9,
    color: colors.light.destructiveForeground,
    lineHeight: 16,
  },
  cursor: {
    fontFamily: "Inter_400Regular",
    fontSize: 15,
    // Slight indent so the bar isn't kissed up against the last
    // character in the same line.
    marginLeft: 1,
  },
  signalsContainer: {
    paddingHorizontal: 16,
    paddingVertical: 4,
    gap: 4,
    alignItems: "flex-start",
  },
  signalRow: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: colors.light.muted,
  },
  signalText: {
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    fontStyle: "italic",
    color: colors.light.mutedForeground,
  },
  interruptedActions: {
    flexDirection: "row",
    gap: 8,
    marginTop: 8,
    alignItems: "center",
  },
  continueBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: colors.light.primary,
  },
  continueBtnText: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    color: colors.light.primaryForeground,
  },
  retryBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 14,
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: colors.light.border,
  },
  retryBtnText: {
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    color: colors.light.mutedForeground,
  },
  attachBtn: {
    width: 40,
    height: 44,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },
  micBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.light.muted,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 2,
  },
  micBtnRecording: {
    backgroundColor: colors.light.destructive,
  },
  voiceStatus: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 6,
    backgroundColor: colors.light.background,
  },
  voiceDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: colors.light.destructive,
  },
  voiceStatusText: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 12,
    flex: 1,
  },
  voiceErrorText: {
    color: colors.light.destructiveForeground,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    flex: 1,
  },
  speakBtn: {
    alignSelf: "flex-start",
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: colors.light.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  speakBtnText: {
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    color: colors.light.mutedForeground,
  },
  imagePickerCard: {
    backgroundColor: colors.light.background,
    borderTopLeftRadius: 22,
    borderTopRightRadius: 22,
    paddingHorizontal: 18,
    paddingTop: 14,
    paddingBottom: 26,
    gap: 8,
    maxHeight: "92%",
  },
  imagePickerHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  imagePickerPreview: {
    width: "100%",
    height: 180,
    borderRadius: 12,
    backgroundColor: colors.light.muted,
    marginBottom: 4,
  },
  imageCountBadge: {
    position: "absolute",
    bottom: 8,
    right: 8,
    backgroundColor: "rgba(0,0,0,0.6)",
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  imageCountBadgeText: {
    color: "#fff",
    fontFamily: "Inter_500Medium",
    fontSize: 12,
  },
  imagePreviewStrip: {
    maxHeight: 108,
    marginBottom: 12,
  },
  imagePreviewStripContent: {
    gap: 6,
    paddingHorizontal: 4,
    alignItems: "center",
  },
  imagePreviewStripItem: {
    position: "relative",
  },
  imagePreviewStripThumb: {
    width: 96,
    height: 96,
    borderRadius: 8,
    backgroundColor: colors.light.muted,
  },
  imagePreviewRemoveBtn: {
    position: "absolute",
    top: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: "rgba(0,0,0,0.55)",
    alignItems: "center",
    justifyContent: "center",
  },
  imagePreviewRemoveX: {
    color: "#fff",
    fontSize: 11,
    lineHeight: 13,
    fontFamily: "Inter_500Medium",
  },
  imagePickerPreviewWrap: {
    position: "relative",
    marginBottom: 4,
  },
  imagePickerPreviewRemoveBtn: {
    position: "absolute",
    top: 8,
    right: 8,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: "rgba(0,0,0,0.55)",
    alignItems: "center",
    justifyContent: "center",
  },
  modeHint: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 11,
    fontStyle: "italic",
  },
  imageCaptionInput: {
    backgroundColor: colors.light.muted,
    color: colors.light.text,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontFamily: "Inter_400Regular",
    fontSize: 14,
    minHeight: 48,
    maxHeight: 110,
    marginTop: 6,
  },
  medicalNotice: {
    color: colors.light.accent,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    backgroundColor: "rgba(122, 92, 255, 0.10)",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  imagePickerError: {
    color: colors.light.destructive,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
  },
  imagePickerSendBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: colors.light.primary,
    borderRadius: 14,
    paddingVertical: 14,
    marginTop: 10,
  },
  imagePickerSendText: {
    color: colors.light.primaryForeground,
    fontFamily: "Inter_600SemiBold",
    fontSize: 14,
  },
  rememberCard: {
    maxWidth: "85%",
    marginLeft: 4,
    marginVertical: 6,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "rgba(122, 92, 255, 0.35)",
    backgroundColor: "rgba(122, 92, 255, 0.08)",
    gap: 10,
  },
  rememberHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  rememberHeaderText: {
    color: colors.light.text,
    fontFamily: "Inter_600SemiBold",
    fontSize: 13,
  },
  rememberHint: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_400Regular",
    fontSize: 12,
  },
  rememberRow: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
  },
  rememberBtn: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 10,
  },
  rememberBtnPrimary: {
    backgroundColor: colors.light.primary,
  },
  rememberBtnPrimaryText: {
    color: colors.light.primaryForeground,
    fontFamily: "Inter_600SemiBold",
    fontSize: 12,
  },
  rememberBtnSecondary: {
    backgroundColor: colors.light.muted,
  },
  rememberBtnSecondaryText: {
    color: colors.light.text,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
  },
  rememberBtnGhost: {
    backgroundColor: "transparent",
  },
  rememberBtnGhostText: {
    color: colors.light.mutedForeground,
    fontFamily: "Inter_500Medium",
    fontSize: 12,
    textDecorationLine: "underline",
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
});
