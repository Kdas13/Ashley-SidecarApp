/**
 * PRICING WATERFALL
 *
 * Direct implementation of constitution rule pricing-1. The structure is
 * fixed (gross margin -> tax reserve -> shipping reserve -> net profit),
 * the percentages are read from CURRENT_PRICING_CONFIG, never hardcoded
 * here. When the accountant says "it's 22% now," update the config file,
 * not this logic.
 */

import { CURRENT_PRICING_CONFIG } from "./constitution.js";

export interface PricingBreakdown {
  sellPrice: number;
  costToMake: number;
  grossMargin: number;
  taxReserve: number;
  postTaxRemainder: number;
  shippingReserve: number;
  netProfit: number;
}

export function computePricingWaterfall(
  sellPrice: number,
  costToMake: number
): PricingBreakdown {
  if (sellPrice <= 0 || costToMake < 0) {
    throw new Error("Invalid pricing inputs: sellPrice must be > 0, costToMake must be >= 0");
  }

  const grossMargin = sellPrice - costToMake;
  const taxReserve = round2(grossMargin * (CURRENT_PRICING_CONFIG.taxReservePercent / 100));
  const postTaxRemainder = round2(grossMargin - taxReserve);
  const shippingReserve = round2(
    postTaxRemainder * (CURRENT_PRICING_CONFIG.shippingReservePercent / 100)
  );
  const netProfit = round2(postTaxRemainder - shippingReserve);

  return {
    sellPrice,
    costToMake,
    grossMargin: round2(grossMargin),
    taxReserve,
    postTaxRemainder,
    shippingReserve,
    netProfit,
  };
}

/**
 * What the customer actually sees at checkout — never the real backend
 * shipping cost, per constitution rule pricing-2.
 */
export function customerFacingShippingFee(cartSubtotal: number): {
  fee: number;
  isFree: boolean;
} {
  if (cartSubtotal >= CURRENT_PRICING_CONFIG.freeShippingThreshold) {
    return { fee: 0, isFree: true };
  }
  return { fee: CURRENT_PRICING_CONFIG.flatShippingFee, isFree: false };
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}
