/**
 * ACTIVITY LOG
 *
 * Every action Michael takes is recorded here, including which constitution
 * version was live at the time. This is the audit trail that makes it
 * possible to always answer "what did Michael do, and was it following the
 * rules at the time" — never "it must have drifted."
 *
 * Backed by SQLite for v1 (simple, file-based, fine for a single-project
 * scale). Swappable for Postgres later if/when Michael goes multi-project /
 * multi-tenant.
 */

import { getDb } from "./db.js";

export interface ActivityLogEntry {
  projectId: string;
  actionType: string;
  actionDescription: string;
  constitutionVersion: string;
  success: boolean;
  haltedForApproval: boolean;
  approvalReason?: string;
  error?: string;
  timestamp: string;
}

export async function logActivity(entry: ActivityLogEntry): Promise<void> {
  const db = getDb();
  const stmt = db.prepare(`
    INSERT INTO activity_log (
      project_id, action_type, action_description, constitution_version,
      success, halted_for_approval, approval_reason, error, timestamp
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run(
    entry.projectId,
    entry.actionType,
    entry.actionDescription,
    entry.constitutionVersion,
    entry.success ? 1 : 0,
    entry.haltedForApproval ? 1 : 0,
    entry.approvalReason ?? null,
    entry.error ?? null,
    entry.timestamp
  );
}

export async function getRecentActivity(projectId: string, limit = 50) {
  const db = getDb();
  const stmt = db.prepare(`
    SELECT * FROM activity_log
    WHERE project_id = ?
    ORDER BY timestamp DESC
    LIMIT ?
  `);
  return stmt.all(projectId, limit);
}
