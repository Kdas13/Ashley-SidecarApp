/**
 * DATABASE
 *
 * SQLite for v1 — file-based, zero infra cost, fine for single-project
 * scale running on a small Railway/Fly instance. The schema mirrors the
 * data model from the constitution doc Section 6/7 (Project, Vendor,
 * Design, StorefrontState, AdCampaign, ApprovalRequest, ActivityLog,
 * Order).
 *
 * Swap to Postgres later by changing this file only — nothing above this
 * layer should know or care which database engine is underneath.
 */

import Database from "better-sqlite3";

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (db) return db;

  db = new Database(process.env.MICHAEL_DB_PATH ?? "./michael.db");
  db.pragma("journal_mode = WAL");
  initSchema(db);
  return db;
}

function initSchema(database: Database.Database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS projects (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'active',
      manifesto TEXT,
      mission_statement TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS vendors (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'candidate', -- candidate | vetting | approved | rejected
      -- functional gates
      supports_multi_placement INTEGER,
      supports_multi_garment INTEGER,
      is_print_to_order INTEGER,
      auto_cut_on_sale INTEGER,
      -- ethical gates
      manufacturing_location TEXT,
      manufacturing_transparent INTEGER,
      fair_labor_evidence TEXT,
      ethical_verification_status TEXT, -- unverified | outreach_sent | verified | failed
      -- construction-method qualification (json array, e.g. ["vinyl_print","embroidery"])
      construction_methods TEXT,
      pricing_history TEXT, -- json array of {date, product, price}
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS designs (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      name TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'draft', -- draft | pending_review | approved | print_ready | live
      reference_image_urls TEXT, -- json array
      placement_spec TEXT,
      collection TEXT, -- 'luxury' | 'raw'
      available_construction_methods TEXT, -- json array, subset of vendor capability
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS design_vendor_links (
      design_id TEXT NOT NULL REFERENCES designs(id),
      vendor_id TEXT NOT NULL REFERENCES vendors(id),
      construction_method TEXT NOT NULL,
      PRIMARY KEY (design_id, vendor_id, construction_method)
    );

    CREATE TABLE IF NOT EXISTS storefront_state (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      design_id TEXT NOT NULL REFERENCES designs(id),
      is_live INTEGER NOT NULL DEFAULT 0,
      sync_status TEXT, -- synced | pending | error
      last_synced_at TEXT,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ad_campaigns (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      platform TEXT NOT NULL, -- 'instagram' | 'facebook'
      status TEXT NOT NULL DEFAULT 'draft', -- draft | pending_approval | approved | live | paused
      creative_asset_urls TEXT, -- json array
      audience_segment TEXT, -- e.g. 'fitness_18_35', 'fashion_18_35', 'streetwear_18_35'
      target_collection TEXT, -- which collection/construction method this creative pulls from
      spend_cap REAL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS approval_requests (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      gate_id TEXT NOT NULL, -- references APPROVAL_GATES ids from constitution.ts
      payload TEXT NOT NULL, -- json, whatever needs reviewing
      status TEXT NOT NULL DEFAULT 'pending', -- pending | approved | rejected | changes_requested
      response_note TEXT,
      created_at TEXT NOT NULL,
      resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS activity_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      project_id TEXT NOT NULL,
      action_type TEXT NOT NULL,
      action_description TEXT NOT NULL,
      constitution_version TEXT NOT NULL,
      success INTEGER NOT NULL,
      halted_for_approval INTEGER NOT NULL DEFAULT 0,
      approval_reason TEXT,
      error TEXT,
      timestamp TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id TEXT PRIMARY KEY,
      project_id TEXT NOT NULL REFERENCES projects(id),
      customer_email TEXT,
      total_paid REAL NOT NULL,
      shipping_fee_charged REAL NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS order_sub_orders (
      id TEXT PRIMARY KEY,
      order_id TEXT NOT NULL REFERENCES orders(id),
      vendor_id TEXT NOT NULL REFERENCES vendors(id),
      design_id TEXT NOT NULL REFERENCES designs(id),
      construction_method TEXT NOT NULL,
      quantity INTEGER NOT NULL DEFAULT 1,
      size TEXT NOT NULL,
      colour TEXT,
      cost_to_make REAL NOT NULL,
      sell_price REAL NOT NULL,
      tax_reserve REAL NOT NULL,
      shipping_reserve REAL NOT NULL,
      net_profit REAL NOT NULL,
      vendor_shipping_status TEXT, -- pulled from vendor API
      vendor_tracking_number TEXT,
      expected_delivery_window TEXT
    );

    CREATE INDEX IF NOT EXISTS idx_activity_log_project ON activity_log(project_id);
    CREATE INDEX IF NOT EXISTS idx_vendors_project ON vendors(project_id);
    CREATE INDEX IF NOT EXISTS idx_designs_project ON designs(project_id);
  `);
}

export function closeDb() {
  if (db) {
    db.close();
    db = null;
  }
}
