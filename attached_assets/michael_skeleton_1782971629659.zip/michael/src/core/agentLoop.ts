/**
 * AGENT LOOP
 *
 * Michael is event-driven, not always-thinking, per the architecture notes:
 * - Scheduled checks (cron-like): vendor price re-checks, order status,
 *   ad performance — run even when nobody's talking to Michael
 * - Triggered tasks: assigned by Kane via chat, run once, may raise
 *   ApprovalRequests
 * - Approval resolution: resolving an ApprovalRequest unblocks whatever
 *   downstream task was waiting on it
 *
 * This file is the skeleton only — actual tool integrations (vendor APIs,
 * Flux, Meta Ads) plug in via src/tools/ once those are built. Every
 * task/check defined here MUST run through runConstitutionalAction —
 * there is no path that calls a tool directly without it.
 */

import cron from "node-cron";
import { runConstitutionalAction, haltForApproval } from "./constitutionGuard.js";
import { getDb } from "./db.js";

export interface TriggeredTask {
  projectId: string;
  taskType: string;
  description: string;
  payload: Record<string, unknown>;
}

/**
 * Entry point for a task Kane assigns via chat. Wraps it in the
 * constitutional guard and dispatches to the right handler.
 *
 * This is a skeleton — real dispatch logic (vendor_search, design_generate,
 * etc.) gets filled in as each tool integration is built.
 */
export async function dispatchTriggeredTask(task: TriggeredTask) {
  return runConstitutionalAction(
    {
      projectId: task.projectId,
      projectContext: task.payload,
      actionDescription: task.description,
      actionType: task.taskType,
    },
    async (promptBlock, ctx) => {
      // TODO: real dispatch by ctx.actionType once tool integrations exist.
      // Skeleton behaviour: log that the task was received, do nothing yet.
      console.log(`[Michael] Received task: ${ctx.actionType} for project ${ctx.projectId}`);
      console.log(`[Michael] Constitution block length: ${promptBlock.length} chars`);

      // Example of how a task would correctly halt for approval rather
      // than finding a workaround, once real logic exists here:
      // if (taskRequiresSpend) {
      //   return haltForApproval("This task requires creating a vendor account, which needs human approval.");
      // }

      return { success: true, output: { received: true } };
    }
  );
}

/**
 * Scheduled checks — the "background loop" that keeps running on a
 * project even while Kane's chat attention is elsewhere. Each check is
 * its own constitutionally-guarded action, same as triggered tasks.
 */
export function startScheduledChecks() {
  // Daily vendor price re-check — mirrors the existing PC-build
  // watchlist pattern already proven in the Ashley pipeline.
  cron.schedule("0 7 * * *", async () => {
    const projects = getActiveProjectIds();
    for (const projectId of projects) {
      await runConstitutionalAction(
        {
          projectId,
          projectContext: { checkType: "vendor_price_recheck" },
          actionDescription: "Daily scheduled vendor price re-check",
          actionType: "scheduled_vendor_price_check",
        },
        async (_promptBlock, _ctx) => {
          // TODO: real vendor price check logic once vendor tool exists.
          return { success: true, output: { checked: true } };
        }
      );
    }
  });

  // Order status sync — pulls vendor fulfillment status, no approval
  // needed since this is pure relay of fact, not a judgment call.
  cron.schedule("*/30 * * * *", async () => {
    const projects = getActiveProjectIds();
    for (const projectId of projects) {
      await runConstitutionalAction(
        {
          projectId,
          projectContext: { checkType: "order_status_sync" },
          actionDescription: "Order status sync from vendor APIs",
          actionType: "scheduled_order_sync",
        },
        async (_promptBlock, _ctx) => {
          // TODO: real order sync logic once vendor tool exists.
          return { success: true, output: { synced: true } };
        }
      );
    }
  });

  console.log("[Michael] Scheduled checks registered.");
}

function getActiveProjectIds(): string[] {
  const db = getDb();
  const rows = db
    .prepare(`SELECT id FROM projects WHERE status = 'active'`)
    .all() as { id: string }[];
  return rows.map((r) => r.id);
}
