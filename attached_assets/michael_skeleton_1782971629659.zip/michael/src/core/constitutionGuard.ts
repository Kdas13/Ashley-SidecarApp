/**
 * CONSTITUTION GUARD
 *
 * This is the single mandatory gateway every Michael action passes through.
 * It is the code-level enforcement of the "Constitution Refresh Pattern"
 * from the constitution document — every action gets a freshly built
 * constitution block, freshly scoped project context, executes, and logs
 * which constitution version was active. Nothing skips this. There is no
 * "fast path" for small actions.
 *
 * If you are tempted to add a bypass for a "quick" or "low-risk" action —
 * don't. That is exactly the shortcut the constitution explicitly forbids,
 * and the same shortcut implicated in real-world agent drift failures.
 */

import { buildConstitutionBlock, CONSTITUTION_VERSION } from "./constitution.js";
import { logActivity } from "./activityLog.js";

export interface MichaelActionContext {
  projectId: string;
  /** Minimal, scoped project state needed for THIS action only — never the full project dump. */
  projectContext: Record<string, unknown>;
  actionDescription: string;
  actionType: string;
}

export interface MichaelActionResult<T = unknown> {
  success: boolean;
  output?: T;
  /** Set when the action was halted because it required crossing a constitutional boundary. */
  haltedForApproval?: boolean;
  approvalReason?: string;
  error?: string;
}

export type MichaelActionFn<T = unknown> = (
  promptBlock: string,
  ctx: MichaelActionContext
) => Promise<MichaelActionResult<T>>;

/**
 * Wraps a single Michael action with the mandatory constitution refresh.
 *
 * Usage:
 *   const result = await runConstitutionalAction(
 *     { projectId, projectContext: {...}, actionDescription: "...", actionType: "vendor_search" },
 *     async (promptBlock, ctx) => {
 *       // actual tool call / LLM call here, using promptBlock as the
 *       // system-prompt prefix, never relying on prior turns' rules.
 *     }
 *   );
 */
export async function runConstitutionalAction<T>(
  ctx: MichaelActionContext,
  action: MichaelActionFn<T>
): Promise<MichaelActionResult<T>> {
  // Step 1 + 2: fresh constitution + minimal scoped context.
  // Both are rebuilt every single call — never cached, never reused
  // across actions, regardless of how close together in time they happen.
  const constitutionBlock = buildConstitutionBlock();

  // Step 3 is implicit: the caller's `action` fn receives the freshly
  // built prompt block and must construct its actual LLM/tool call as
  // [constitutionBlock] + [ctx.projectContext] + [the one task], not
  // append to any prior conversation state.

  let result: MichaelActionResult<T>;
  try {
    // Step 4: execute.
    result = await action(constitutionBlock, ctx);
  } catch (err) {
    result = {
      success: false,
      error: err instanceof Error ? err.message : String(err),
    };
  }

  // Step 5: log the action AND which constitution version was active.
  // This is what makes any future failure diagnosable as either
  // "the rule was wrong" or "the rule wasn't followed" — never "drift."
  await logActivity({
    projectId: ctx.projectId,
    actionType: ctx.actionType,
    actionDescription: ctx.actionDescription,
    constitutionVersion: CONSTITUTION_VERSION,
    success: result.success,
    haltedForApproval: result.haltedForApproval ?? false,
    approvalReason: result.approvalReason,
    error: result.error,
    timestamp: new Date().toISOString(),
  });

  // Step 6: nothing persists from this call into the next one. The
  // promptBlock, the constructed context, all of it is scoped to this
  // function call and goes out of scope on return. The next call to
  // runConstitutionalAction rebuilds from scratch.

  return result;
}

/**
 * Helper for actions that recognise mid-execution they're about to cross
 * a constitutional boundary. Use this instead of finding a workaround.
 */
export function haltForApproval(reason: string): MichaelActionResult<never> {
  return {
    success: false,
    haltedForApproval: true,
    approvalReason: reason,
  };
}
