import { test } from "node:test";
import assert from "node:assert/strict";
import { computePricingWaterfall, customerFacingShippingFee } from "../pricing.js";

test("pricing waterfall matches constitution worked example: £25 sell, £10 cost", () => {
  const result = computePricingWaterfall(25, 10);

  assert.equal(result.grossMargin, 15);
  assert.equal(result.taxReserve, 3); // 20% of 15
  assert.equal(result.postTaxRemainder, 12);
  assert.equal(result.shippingReserve, 2.4); // 20% of 12
  assert.equal(result.netProfit, 9.6);
});

test("customer-facing shipping: flat fee below threshold", () => {
  const result = customerFacingShippingFee(50);
  assert.equal(result.fee, 6.99);
  assert.equal(result.isFree, false);
});

test("customer-facing shipping: free at/above threshold", () => {
  const result = customerFacingShippingFee(150);
  assert.equal(result.fee, 0);
  assert.equal(result.isFree, true);
});

test("pricing waterfall rejects invalid inputs", () => {
  assert.throws(() => computePricingWaterfall(0, 10));
  assert.throws(() => computePricingWaterfall(25, -5));
});
