/**
 * MICHAEL ENTRY POINT
 *
 * Minimal Express server: health check + a single chat endpoint that
 * dispatches messages as triggered tasks. This is intentionally bare —
 * the workspace UI, real LLM integration, and tool wiring all come after
 * this skeleton is confirmed working end to end.
 */

import express from "express";
import dotenv from "dotenv";
import { dispatchTriggeredTask } from "./core/agentLoop.js";
import { startScheduledChecks } from "./core/agentLoop.js";
import { getDb } from "./core/db.js";
import { CONSTITUTION_VERSION } from "./core/constitution.js";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = process.env.PORT ?? 3000;

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    constitutionVersion: CONSTITUTION_VERSION,
    timestamp: new Date().toISOString(),
  });
});

// Minimal chat dispatch — this is the "command line into Michael" from the
// architecture notes. Real version will stream LLM responses; this
// skeleton just proves the constitutional dispatch path works.
app.post("/chat", async (req, res) => {
  const { projectId, message } = req.body as { projectId?: string; message?: string };

  if (!projectId || !message) {
    return res.status(400).json({ error: "projectId and message are required" });
  }

  const result = await dispatchTriggeredTask({
    projectId,
    taskType: "chat_message",
    description: message,
    payload: { rawMessage: message },
  });

  res.json(result);
});

app.get("/projects/:id/activity", (req, res) => {
  const db = getDb();
  const rows = db
    .prepare(`SELECT * FROM activity_log WHERE project_id = ? ORDER BY timestamp DESC LIMIT 50`)
    .all(req.params.id);
  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`[Michael] Listening on port ${PORT}. Constitution: ${CONSTITUTION_VERSION}`);
  startScheduledChecks();
});
