# Michael — Orchestrator Skeleton (v0.1.0)

This is the working skeleton for Michael, scaffolded 30 June 2026. It is a
real, runnable Node.js/TypeScript project — not pseudocode. Tests pass,
it builds clean, and the server runs and dispatches actions through the
full constitutional guard.

## What's REAL in this skeleton

- **`src/core/constitution.ts`** — the constitution as live, structured
  data (not just a text doc). Currently CONSTITUTION_VERSION
  `v3-2026-06-30`, matching the Drive/txt document of the same version.
- **`src/core/constitutionGuard.ts`** — the mandatory wrapper every
  single action passes through. Builds a fresh constitution block,
  executes the action, logs which version was active. This is the actual
  enforcement of the "Constitution Refresh Pattern," not just a
  description of it.
- **`src/core/pricing.ts`** — the pricing waterfall (margin -> tax
  reserve -> shipping reserve -> net profit), proven against your exact
  worked example (£25 sell / £10 cost -> £9.60 net profit) in
  `src/core/__tests__/pricing.test.ts`. All 4 tests pass.
- **`src/core/db.ts`** — full SQLite schema for every entity from the
  architecture notes: projects, vendors, designs, storefront_state,
  ad_campaigns, approval_requests, activity_log, orders +
  order_sub_orders (for the multi-vendor split-shipping model).
- **`src/core/agentLoop.ts`** — the event-driven loop: scheduled checks
  (cron-based, currently a daily vendor price check + 30-min order sync
  stub) and triggered tasks (dispatched from chat), both routed through
  the constitutional guard, neither with a bypass.
- **`src/index.ts`** — minimal Express server: health check, a `/chat`
  endpoint that proves the dispatch path works, an `/activity` endpoint
  to read back the audit log.

Verified working: `npm test` (4/4 pass), `npm run build` (clean), and a
live run proving `/health` and `/chat` both respond correctly and the
activity log records the constitution version on every action.

## What's INTENTIONALLY STUBBED (not yet built)

These are marked `// TODO` in the code. Nothing here was skipped by
accident — they're the next layer, deliberately left out so the
skeleton itself could be verified solid first:

- Real Claude API calls inside action handlers (currently just logs and
  returns success)
- Tool integrations: web search, vendor APIs (Printful/Printify/Gelato),
  Flux/Black Forest Labs, Meta Ads API, email send
- Real dispatch logic by action type (vendor_search, design_generate,
  etc.) — currently `dispatchTriggeredTask` just receives and logs
- The workspace/chat web UI — currently just a raw POST endpoint, no
  frontend
- Site builder integration (Base44 or Replit, as a callable tool)

## Running it yourself

```
npm install
npm test        # run the test suite
npm run build    # compile TypeScript -> dist/
npm run dev      # run with hot reload (tsx watch)
npm start        # run the compiled build
```

Hits `http://localhost:3000/health` and `http://localhost:3000/chat`
(POST, body `{"projectId": "nrnl", "message": "..."}`) once running.

## Hosting

This is designed to run as a single small always-on process — exactly
the Railway/Fly.io-style hosting discussed (a few pounds a month,
separate from Replit Agent as a build dependency). SQLite is file-based,
so on Railway you'd want a persistent volume mounted for `michael.db`, or
swap to Postgres (Railway offers this natively) once it matters — the
db.ts layer is written so that swap doesn't touch anything above it.

## Keeping the constitution in sync

If the constitution document (Drive / the txt files) gets updated again,
`src/core/constitution.ts` needs to be updated to match by hand, and
`CONSTITUTION_VERSION` bumped. This is currently a manual sync step —
worth automating later (e.g. constitution doc becomes the actual source
of truth and this file is generated from it) but for now, the .ts file
IS authoritative for what Michael actually enforces, so it must never
silently drift from the documented version.
